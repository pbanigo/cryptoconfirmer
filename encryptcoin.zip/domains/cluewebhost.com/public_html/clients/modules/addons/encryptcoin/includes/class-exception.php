<?php
/**
 * EncryptCoin is a real peer-to-peer payment gateway for WHMCS which allows you to accept cryptocurrency payments
 * without transaction fees, monthly fee or bank account
 *
 * @package EncryptCoin
 * @author ZintaThemes
 * @version 1.0
 * @link https://zintathemes.com
 *
 */

if (! defined ( "WHMCS" )) die ( "This file cannot be accessed directly" );

if (! class_exists('EncryptCoinException')) {

    class EncryptCoinException extends Exception {

    private $helper;

      /**
       * @access    public
       * @since    1.0.0
       * @var      unown
       */
      public function __construct( $message ) {
      $this->helper = new encryptCoinHelper();
      }

      /**
     * @access      public
     * @since       1.0.0
     * @var         unown
         */
    public function getMessage($value='') {
      $this->helper->_error( $message );
      return false;
      }

    }
}
