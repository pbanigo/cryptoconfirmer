<?php
/**
 * EncryptCoin is a real peer-to-peer payment gateway for WHMCS which allows you to accept cryptocurrency payments
 * without transaction fees, monthly fee or bank account
 *
 * @author     ZintaThemes
 * @package   EncryptCoin
 * @since     1.0
 * @version   1.0.1
 */

! defined ( "WHMCS" ) && die ( "This file cannot be accessed directly" );

use WHMCS\Database\Capsule;

/**
 * Main class of encryptCoinAdmin addon, this class will be call in admin page only
 *
 * @access     public
 * @author     Zinta
 * @since     1.0
 * @version   1.0
 */
if ( ! class_exists ( 'encryptCoinAddressesList' ) ) {

  class encryptCoinAddressesList extends encryptCoinInit
  {

    /**
     * [private description]
     *
     * @var array
     */
    private $vars = [];

    /**
     * [private description]
     *
     * @var string
     */
    private $msg = '';

    /**
     * [private description]
     *
     * @var string
     */
    private $state = 'success';

    /**
     * [private description]
     *
     * @var int
     */
    private $per_page = 20;

    /**
     * [private description]
     *
     * @var int
     */
    private $num_pages = 1;

    /**
     * [__construct description]
     *
     * @method __construct
     * @param  array       $vars   [description]
     * @param  [type]      $search [description]
     * @param  [type]      $delete [description]
     * @param  [type]      $page   [description]
     */
    function __construct() {
      // $delete = ( string ) self::$helper->_get('delete');
      // !empty( $delete ) && $this->delete( $delete );

      $delete = ( string ) self::$helper->_post('delete');
      !empty( $delete ) && $this->delete( $delete );

      $this->addresses_list();
    }

    /**
     * [list description]
     *
     * @method list
     * @param  string $search [description]
     * @return [type]         [description]
     */
    private function addresses_list() {
      $search = ( string ) self::$helper->_get('s');
      $filter = ( string ) self::$helper->_get('filter');
      $page = ( int ) self::$helper->_get('page');
      try {
        $list = $this->data( 'encryptcoin_addresses' )->where( 'testnet', '=', self::$testnet );

        if ( ! empty( $search ) ) {
          $list = $list->where( 'address', 'like', "%{$search}%" );
        }

        if ( ! empty( $filter ) && 'clear' !== $filter ) {
          $list = $list->where( 'code', '=', $filter );
        }

        $list = $this->count( $list, $page );
        $this->get_list(
          $list->get()
        );

      } catch ( Exception $e ) {
        $this->msg = 'ERROR11: ' . $e->getMessage();
        $this->state = 'danger';
      }
      exit();
    }

    /**
     * [count description]
     *
     * @method count
     * @param  [type] $list [description]
     * @return [type]       [description]
     */
    private function count( $list, $page ) {
      $count = $list->count('id');
      if ( $count > $this->per_page ) {
        $this->num_pages = ceil( $count / $this->per_page );
        if ( $page > $this->num_pages ) {
          $page = $this->num_pages;
        } elseif ( $page < 1 ) {
          $page = 1;
        }
        $this->num_pages > 1 && $this->pages( $page );
        $list = $list->skip( ( $page - 1 ) * $this->per_page )->take( $this->per_page );
      }
      return $list;
    }

    /**
     * [get_list description]
     *
     * @method get_list
     * @param  [type]   $info    [description]
     * @param  [type]   $address [description]
     * @return [type]            [description]
     */
    private function get_list( $addresses ) {
      $this->message();
      foreach ( $addresses as $address ) {
        $this->content( $address );
      }
    }

    /**
     * [delete description]
     *
     * @method delete
     * @param  [type] $delete [description]
     * @return [type]         [description]
     */
    private function delete( $delete ) {
      $delete = explode( ',', $delete );
      try {
        if ( $delete = $this->data( 'encryptcoin_addresses' )->whereIn( 'id', $delete )->delete() ) {
          $this->msg = self::$lang['addressDeleted'];
        } else {
          $this->msg = self::$lang['addressDeletedError'];
          $this->state = 'danger';
        }
      } catch ( Exception $e ) {
        $this->msg = self::$lang['addressDeletedError'] . ': ' . $e->getMessage();
        $this->state = 'danger';
      }
    }

    /**
     * [data description]
     *
     * @method data
     * @param  [type] $tbl [description]
     * @return [type]      [description]
     */
    private function data( $tbl ) {
      return Capsule::table( $tbl );
    }

    /**
     * [content description]
     *
     * @method content
     * @param  [type]  $info    [description]
     * @param  [type]  $address [description]
     * @return [type]           [description]
     */
    private function content( $address = [] ) {
      $test = parent::$testnet ? '<label class="label label-danger">TestNet</label>' : '';
      $cryptocoins = self::$_currencies[$address->code];
      $code = $address->currency_id;
      $info = class_exists('encryptCoinAddresses') ? encryptCoinAddresses::addresses_body( $address ) : '';
      $address_v = $this->print_address( $address->id, $address->address );

      echo<<<HTML
      <tr>
        <td class="addresses-list-table__currency"><input class="addresses-form-checkbox" type="checkbox" name="delete-addresses[{$address->id}]" value="{$address->id}"></td>
        <td class="addresses-list-table__currency fieldarea">
          <div class="addresses-list-table__currency__icon" data-title="{$cryptocoins['name']}">
            <img style="width:20px;" src="../modules/addons/encryptcoin/assets/images/icons/{$cryptocoins['slug']}.svg"/>
          <div>
        </td>
        <td class="addresses-list-table__key fieldarea">
          <code>{$address_v}</code>
          {$test}
        </td>
        {$info}
        <td class="added-date fieldarea">{$address->added_date}</td>
      </tr>
HTML;
    }

    /**
     * Prints an address.
     *
     * @param      string  $id       The identifier
     * @param      string  $address  The address
     *
     * @return     string  ( description_of_the_return_value )
     */
    private function print_address( $id, $address ) {
      return ! class_exists( 'encryptCoinDetails' ) ? $address : encryptCoinDetails::address_link( $id, $address );
    }

    /**
     * [pages description]
     *
     * @method pages
     * @param  string $value [description]
     * @return [type]        [description]
     */
    private function pages( $page = 0 ) {
      echo '<tr><td id="encryptcoin-addresses-numpages" class="fieldarea" colspan="10" data-numpages="' . $this->num_pages . '">' . sprintf( self::$lang['pages-info'], $page, $this->num_pages ) . '</td></tr>';
    }

    /**
     * [message description]
     *
     * @method message
     * @param  [type]  $m [description]
     * @return [type]     [description]
     */
    private function message() {
      if ( empty($this->msg) ) {
        return '';
      }

      echo <<<HTML
      <tr>
        <td class="fieldarea" colspan="10">
          <div class="panel panel-health-check panel-health-check-{$this->state}">
            <div class="panel-heading"><small>{$this->msg}</small></div>
          </div>
        </td>
      </tr>
HTML;
    }
  }
}
