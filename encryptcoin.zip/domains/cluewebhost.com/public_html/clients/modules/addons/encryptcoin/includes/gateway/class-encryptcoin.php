<?php
/**
 * This file implements encryptcoin.
 *
 * @author      ZintaThemes
 * @since       2020
 * @version     4.1.3
 */

namespace EncryptCoin;

! defined("WHMCS") && die("This file cannot be accessed directly");

/**
 *
 */
class EncryptCoin
{

  /**
   * [private description]
   *
   * @var [type]
   */
  private static $_instance = false;

  /**
   * [private description]
   *
   * @var [type]
   */
  protected static $gateway = [];

  /**
   * [private description]
   *
   * @var [type]
   */
  protected static $testnet = false;


  /**
   * [private description]
   *
   * @var [type]
   */
  protected static $version = '4.1.3';

  /**
   * currencies code
   *
   * @var        array
   */
  protected static $_currencies = [
    'BTC' => [
      'name' => 'Bitcoin',
      'slug' => 'bitcoin'
    ],
    'BCH' => [
      'name' => 'Bitcoin Cash',
      'slug' => 'bitcoincash'
    ],
    'ETH' => [
      'name' => 'Ethereum',
      'slug' => 'ethereum'
    ],
    'USDT' => [
      'name' => 'Tether',
      'slug' => 'tether',
    ],
    'LTC' => [
      'name' => 'Litecoin',
      'slug' => 'litecoin'
    ],
    'DASH' => [
      'name' => 'Dash',
      'slug' => 'dash'
    ],
    'XRP' => [
      'name' => 'XRP',
      'slug' => 'xrp'
    ],
  ];

  /**
   * language
   * @var array
   */
  protected static $_lang = [];

  /**
   * [private description]
   *
   * @var [type]
   */
  private static $_cookie = 'encryptcoin_address';

  /**
   * @return     None  ''
   */
  function __construct( $params ) {
    self::$testnet = 'on' === $params['testNet'];

    if ( self::$testnet ) {
      $_currencies = self::$_currencies;
      self::$_currencies = [
        'BTC' => $_currencies['BTC'],
        // 'BCH' => $_currencies['BCH'],
        // 'ETH' => $_currencies['ETH']
      ];
    }

    $lang = $params['clientdetails'] && $params['clientdetails']['language'] ? $params['clientdetails']['language'] : 'english';

    self::$_lang = self::get_lang( $lang );

    $libs = [ 'converter', 'form', 'gateway', 'transaction', 'addresses', 'api' ];
    $path = dirname( __FILE__ ) . DIRECTORY_SEPARATOR;

    foreach ( $libs as $lib ) {
      $f = $path . "class-{$lib}.php";
      if ( file_exists( $f ) ) {
        require_once  $f;
      }
    }

    return self::$_instance = true;
  }

  /**
   * { function_description }
   *
   * @return     array  ( description_of_the_return_value )
   */
  public static function metadata() {
    return;
  }

  /**
   * Config
   *
   * @return     array  config
   */
  public static function config() {
    global $aInt;
    $lang = self::get_lang($aInt->language);

    return [
      'FriendlyName' => [
        'Type' => 'System',
        'Value' => 'EncryptCoin'
      ],
      'numberOfConfirmations' => [
        'FriendlyName' => $lang['numberOfConfirmations'],
        'Type' => 'text',
        'Size' => '2',
        'Default' => '3',
        'Description' => $lang['numberOfConfirmationsD'],
      ],
      'ExchangeRateMargin' => [
        'FriendlyName' => $lang['ExchangeRateMargin'],
        'Type' => 'text',
        'Size' => '1',
        'Default' => '1',
        'Description' => $lang['ExchangeRateMarginD'],
      ],
      'AutoAcceptOrder' => [
        'FriendlyName' => $lang['AutoAcceptOrder'],
        'Type' => 'yesno',
        'Default' => 'on',
        'Description' => $lang['AutoAcceptOrderD'],
      ],
      'testNet' => [
        'FriendlyName' => $lang['testNet'],
        'Type' => 'yesno',
        'Default' => '',
        'Description' => $lang['testNetD']
      ],
    ];
  } // End config()

  /**
   * { function_description }
   *
   * @param      <type>           $params  The parameters
   *
   * @return     EncryptCoinForm  The encrypt coin form.
   */
  public static function link( $params ) {
    if ( ! self::get_attr('id') || ! is_array( $params ) || empty( $params ) ) {
      return;
    }
    $info = [];

    if (! self::$_instance) {
      new self( $params );
    }

    if ( !isset($params['numberOfConfirmations']) ) {
      $params['numberOfConfirmations'] = 3;
    }

    $gateway = ( new BitcoinGateway() )->get_gateway( $params['invoiceid'] );

    foreach ( self::$_currencies as $key => $value) {
      if ( in_array( $key, $gateway ) ) {
        self::$gateway[] = $key;
      }
    }

    if ( self::post_attr('encryptcoin') && self::post_attr('id') ) {
      $info = (new EncryptCoinAddresses( $params ))->info;
      $args = [
        'numberOfConfirmations' => (int) $params['numberOfConfirmations'],
        // 'AcceptAnyAmount' => $params['AcceptAnyAmount'],
        'AutoAcceptOrder' => $params['AutoAcceptOrder'] === 'on',
        'testNet' => $params['testNet'] === 'on',
        'lang' => self::$_lang,
      ];

      if ('1' === self::post_attr( 'tx' ) && ! empty( $info )) {
        new EncryptCoinTransaction( $info, $args );
      }
    }

    return ( new EncryptCoinForm( $info, $params ) )->html();
  }

  /**
   * Gets the language.
   *
   * @param      <type>  $params  The parameters
   *
   * @return     <type>  The language.
   */
  private static function get_lang( $lang ) {
    $lang_path = ROOTDIR . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'addons' . DIRECTORY_SEPARATOR . 'encryptcoin' . DIRECTORY_SEPARATOR . 'lang' . DIRECTORY_SEPARATOR;

    $english = [];

    $english_f = $lang_path . 'english.php';
    if ( file_exists( $english_f ) ) {
      include_once $english_f;
      $english = $_ADDONLANG;
    }

    $lang_file = $lang_path . $lang . '.php';
    if ( file_exists( $lang_file ) ) {
      require_once( $lang_file );
    }

    return (array) $_ADDONLANG + (array) $english;
  }

  /**
   * [get_content description]
   *
   * @method get_content
   * @param  string      $url [description]
   * @return [type]           [description]
   */
  protected function get_content( $url = '' ) {
    if ( ! function_exists('curl_version') ) return false;
    $data = [];

    $ch = curl_init();
    curl_setopt_array( $ch, [
       CURLOPT_URL => $url,
       CURLOPT_TIMEOUT => 60,
       CURLOPT_RETURNTRANSFER => true
    ]);
    $response = curl_exec($ch);

    curl_close($ch);
    $response = json_decode( $response, true );

    if ( is_array( $response ) && !empty( $response ) ) {
      $data = $response;
    }
    return $data;
  }

  /**
   * [message description]
   *
   * @method message
   * @param  [type]  $message [description]
   * @param  [type]  $status  [description]
   * @return [type]           [description]
   */
  protected function message( $message, $status ) {
    switch ($status) {
      case 'error':
        $icon = 'times-circle';
        break;

      case 'warning':
        $icon = 'info-circle';
        break;

      default:
        $icon = 'check-circle';
        break;
    }
    echo '<div class="' . $status . '">' . $message. ' <i class="fa fa-' . $icon . '"></i></div></div>';
    exit();
  }

  /**
   * [_post description]
   *
   * @method _post
   * @param  [type] $param [description]
   * @return [type]        [description]
   */
  protected static function post_attr( $param = '' ) {
    return isset($_POST[$param]) && ! empty($_POST[$param]) ? $_POST[$param] : '';
  }

  /**
   * [_get description]
   *
   * @method _get
   * @param  [type] $param [description]
   * @return [type]        [description]
   */
  protected static function get_attr( $param = '' ) {
    return isset($_GET[$param]) && ! empty( $_GET[$param] ) ? $_GET[$param] : '';
  }

}
