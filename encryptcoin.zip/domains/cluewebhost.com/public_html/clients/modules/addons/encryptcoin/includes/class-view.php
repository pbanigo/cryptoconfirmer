<?php
/**
 * EncryptCoin is a real peer-to-peer payment gateway for WHMCS which allows you to accept cryptocurrency payments
 * without transaction fees, monthly fee or bank account
 *
 * @package EncryptCoin
 * @author ZintaThemes
 * @version 1.0
 * @link https://zintathemes.com
 *
 */

! defined ( "WHMCS" ) && die ( "This file cannot be accessed directly" );

if ( ! class_exists( 'encryptCoinView' ) ) {

  class encryptCoinView extends encryptCoinInit
  {

    /**
     * [private description]
     *
     * @var [type]
     */
    private static $_instance = false;

    /**
     * Initialize the class and set its properties.
     *
     * @since   1.0
     * @param   string      $plugin_name    The name of this plugin.
     * @param   string      $version        The version of this plugin.
     */
    public function __construct() {
      $this->main();
    }

    /**
     * [main description]
     *
     * @method main
     * @return [type]               [description]
     */
    public function main() {
      $test = self::$testnet ? ' (TestNet)' : '';

      $this->header();
      $this->tabs( $test );
      ?>
      <div class="tab-content admin-tabs">
        <?php
        $this->transactions_list();
        $this->activitylog();
        $this->addresses_list();
        $this->curreency( $test );
        $this->help();
        ?>
      </div>
      <?php
      parent::version_alert();
      $this->footer();
    }

    /**
     * [header description]
     *
     * @method header
     * @since   1.0
     * @return [type]       [description]
     */
    public function header() {
      ?>
      <link href="../modules/addons/encryptcoin/assets/css/admin.min.css?v=<?php echo self::$version; ?>" rel="stylesheet"/>
      <div id="encryptcoin">
      <?php
      if ( self::$testnet ) :
        ?>
        <div class="infobox">
          <strong><span class="title"><?php echo self::$lang['warning']; ?></span></strong>
          <br><?php echo self::$lang['TestNetActivated']; ?>
        </div>
        <?php
      endif;
    }

    /**
     * [list description]
     *
     * @method list
     * @return [type]       [description]
     */
    public function addresses_list() {
      ?>
      <div id="tab2" class="tab-pane">
        <table class="form" width="100%" cellspacing="2" cellpadding="3" border="0">
          <tbody>
            <tr>
              <td class="encryptcoin-toolbar">
                <input id="encryptcoin-addresses-toolbar-search" type="text" name="" placeholder="Search">
                <?php
                foreach ( self::$_currencies as $key => $value ) :?>
                  <a href="#" class="encryptcoin-addresses-toolbar-fliter-currencies" data-title="<?php echo $value['name'];?>" data-code="<?php echo $key;?>">
                    <img style="width:20px;" src="../modules/addons/encryptcoin/assets/images/icons/<?php echo $value['slug'];?>.svg"/>
                  </a>
                <?php endforeach; ?>

                <a href="#" id="encryptcoin-addresses-toolbar-refresh" class="pull-right"><i class="fa fa-sync"></i></a>
                <span class="pull-right"></span>
                <a href="#" class="encryptcoin-addresses-toolbar-pages pull-right" data-pages="next" title="Next"><i class="fa fa-angle-right"></i></a>
                <a href="#" class="encryptcoin-addresses-toolbar-pages pull-right" data-pages="previous" title="Previous"><i class="fa fa-angle-left"></i></a>
                <span class="pull-right"></span>
                <button type="submit" name="delete-selected" class="encryptcoin-addresses-toolbar-delete delete pull-right" data-confirm="<?php echo self::$lang['areYouSure'];?>" data-title="<?php echo self::$lang['deleteSelected'];?>"><i class="fa fa-trash-alt"></i></button>
              </td>
            </tr>
          </tbody>
        </table>
        <form id="addresses-form" method="post" action="">
          <table class="addresses-list-table datatable" width="100%" cellspacing="2" cellpadding="3" border="0">
            <thead>
              <tr>
                <th class="addresses-list-table__currency"><input class="addresses-form-selectall" type="checkbox" name="addresses-form-selectall" value="all"></th>
                <th class="addresses-list-table__currency"> </th>
                <th class="addresses-list-table__key"><?php echo self::$lang['address']; ?></th>
                <?php
                if ( class_exists( 'encryptCoinAddresses' ) ) {
                  encryptCoinAddresses::addresses_head();
                }
                ?>
                <th class="added-date"><?php echo self::$lang['addedDate']; ?></th>
              </tr>
            </thead>
            <tbody id="addresses-list"></tbody>
          </table>
        </form>
      </div>
      <?php
    }

    /**
     * { function_description }
     */
    public function transactions_list() {
      class_exists('encryptCoinTransactions') && class_exists('encryptCoinTransactions') && encryptCoinTransactions::transactions_view();
    }

    /**
     * { function_description }
     */
    public function activitylog() {
      class_exists('encryptCoinActivitylog') && encryptCoinActivitylog::activitylog_view();
    }

    /**
     * [curreency description]
     *
     * @method curreency
     * @return string                  [description]
     */
    public function curreency( $test ) {
      foreach ( self::$_currencies as $key => $value ) :?>
        <div id="tab-<?php echo $key;?>" class="tab-pane">
          <table class="form" width="100%" cellspacing="2" cellpadding="3" border="0">
            <tbody>
                <tr>
                  <td class="fieldarea">
                    <h2>
                      <img style="width:40px;" src="../modules/addons/encryptcoin/assets/images/icons/<?php echo $value['slug'];?>.svg"/>
                      <?php echo $value['name'] . $test; ?>
                    </h2>

                    <div class="encryptcoin-address-list"></div>
                    <p><?php echo self::$lang['donotUseAddresses']; ?></p>
                    <?php
                    if ( 'XRP' === $value['name'] || 'xrp' === $value['slug'] ) {
                      ?>
                      <div class="panel panel-health-check panel-health-check-warning">
                        <div class="panel-heading"><i class="fas fa-exclamation-triangle"></i> <?php echo self::$lang['xrpTag'];?></div>
                        <div class="panel-body">
                          <?php echo sprintf(self::$lang['xrpTagWarning'], 'r00000000000000000000000000000000:000000000');?>
                        </div>
                      </div>
                    <?php
                    }
                    ?>
                    <textarea class="form-control encryptcoin-addresses-textarea" name="addresses-list" rows="4" cols="210"></textarea>
                    <small><i><?php printf( self::$lang['addAddresses'], $value['name'] ); ?></i></small>
                  </td>
                </tr>
              </tbody>
          </table>
          <a href="#" class="btn btn-default encryptcoin-add-addresses-button" data-code="<?php echo $key;?>">
            <?php echo self::$lang['add']; ?>
          </a>
        </div>
        <?php
      endforeach;
    }

    /**
     * [tabs description]
     *
     * @method tabs
     * @param  string $config [description]
     * @return [type]         [description]
     */
    public function tabs( $test ) {
      $active_a = 'active ';
      $active_t = '';
      if ( class_exists('encryptCoinTransactions') ) {
        $active_t = 'active ';
        $active_a = '';
      }
      ?>
      <ul class="nav nav-tabs admin-tabs" role="tablist">
        <li class="dropdown pull-right tabdrop hide">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="icon-align-justify"></i><b class="caret"></b></a>
          <ul class="dropdown-menu"></ul>
        </li>
        <?php
        // new encryptCoinTransactions();
        if ( class_exists('encryptCoinTransactions') ):
          ?>
          <li class="<?php echo $active_t; ?>encryptcoin-transactions-list-tab"><a class="tab-top" href="#tab0" role="tab" data-toggle="tab" id="tabLink0" data-tab-id="0"><?php echo self::$lang['transactions']; ?></a></li>
          <?php
        endif;
        ?>
        <li class="<?php echo $active_a; ?>encryptcoin-activitylog-list-tab"><a class="tab-top" href="#tab1" role="tab" data-toggle="tab" id="tabLink1" data-tab-id="1"><?php echo self::$lang['activitylog']; ?></a></li>
        <li class="encryptcoin-address-list-tab"><a class="tab-top" href="#tab2" role="tab" data-toggle="tab" id="tabLink2" data-tab-id="2"><?php echo self::$lang['addresses']; ?></a></li>
        <?php
        $i = 3;
        foreach ( self::$_currencies as $key => $value ) :?>
          <li>
            <a class="tab-top" href="#tab-<?php echo $key;?>" role="tab" data-toggle="tab" id="<?php echo $key;?>" data-tab-id="<?php echo $i;?>">
              <img style="width:15px;" src="../modules/addons/encryptcoin/assets/images/icons/<?php echo $value['slug'];?>.svg"/> <?php echo $key . $test; ?>
            </a>
          </li>
          <?php
          $i++;
        endforeach;
        ?>
        <li class="pull-right"><a class="tab-top" href="#tab100" role="tab" data-toggle="tab" id="tabLink100" data-tab-id="100"><?php echo self::$lang['help']; ?></a></li>
      </ul>
      <?php
    }

    /**
     * [footer description]
     *
     * @method footer
     * @param  [type] $config [description]
     * @return [type]         [description]
     */
    public function footer() {
      // if ( ! class_exists('encryptCoinTransactions') ) :
      ?>
      <hr/>
      <small>
        <?php echo self::$lang['reviewVeryImportant'];?>
        <a target="_blank" href="https://marketplace.whmcs.com/product/5260#reviews">
          <span style="color: #FFC800;">
            <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>
          </span>
          <?php echo self::$lang['clickToKeepFeedback'];?>
        </a>
        </small>
      <?php
      // endif;
      ?>
      </div><script src="../modules/addons/encryptcoin/assets/js/admin.min.js?v=<?php echo self::$version; ?>"></script>
      <?php
    }

    /**
     * [Help description]
     *
     * @method Help
     * @param  string $encryptcoin [description]
     * @param  string $version     [description]
     */
    public function help() {
      $lang = self::$lang;
      $version = self::$version;
      $lite = $this->help_title();

      $importan = '';
      foreach ( $lang['importantList'] as $value) {
        $importan .= <<<HTML
        <li>{$value}</li>
HTML;
      }

      echo <<<HTML
      <div id="tab100" class="tab-pane">

        <section class="text-center">
          <img style="width:50px;" src="../modules/addons/encryptcoin/assets/images/icons/encryptcoin.svg">
          <h2>{$lang['intro']} V{$version} {$lite}</h2>
        </section>

        <div class="panel panel-health-check panel-health-check-warning">
          <div class="panel-heading"><i class="fas fa-exclamation-triangle"></i> {$lang['important']}</div>
          <div class="panel-body">
            <ol>{$importan}</ol>
          </div>
        </div>

        <hr/>

        <div class="panel panel-default">
          <div class="panel-body">
            {$lang['unsupported']}
            <a target="_blank"href="https://clients.zintahost.com/?helptab=note">{$lang['fromHere']}</a>
          </div>
        </div>

      </div>
HTML;
    }

    /**
     * { function_description }
     *
     */
    private function help_title() {
      $color = 'danger';
      $title = 'Liet';
      $content = '';
      if ( class_exists( 'encryptCoinAddresses' ) ) {
        $color = 'success';
        $title = 'Pro';
      } else {
        $content = '<hr/><small>Get more features with <span class="label label-success"><big>PRO</big></span> version <a href="https://clients.zintahost.com/link.php?id=2" target="_blank">from here</a>.</small>';
      }
      return '<span class="label label-' . $color . '"><big>' . $title . '</big></span>' . $content;
    }

  } // end of class encryptCoinView
}
