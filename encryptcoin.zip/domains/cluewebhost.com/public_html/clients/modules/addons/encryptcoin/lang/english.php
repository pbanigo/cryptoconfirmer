<?php
/**
 * File name       english.php
 *
 */

! defined('WHMCS') && die('This file cannot be accessed directly');

$_ADDONLANG = [
  //
  // Addon -----------------------------------------Start//
  'intro' => 'EncryptCoin',
  'description' => 'Real peer-to-peer payment gateway for WHMCS.',

  'errorButTryAgain' => 'An error occurred, please try again.',
  'clickHere' => 'click Here',
  'fromHere' => 'from here',
  'help' => 'Help',
  'date' => 'Date',
  'id' => 'ID',
  'yes' => 'Yes',
  'no' => 'No',
  'areYouSure' => 'are you sure?',
  'clear' => 'Clear',
  'close' => 'Close ...',

  'address' => 'Address',
  'destinationTag' => 'Destination Tag',
  'addresses' => 'Addresses',
  'addAddresses' => 'Enter %s addresses in the field above, one per line. Then click Add button.', // %s = currency name
  'addressSuccessAdded' => 'Address was successfully added.',
  'invalidAddress' => 'Make sure to add correct address.',
  'addressExist' => 'Address is already there.',
  'addressDeleted' => 'Addresses was deleted successfully.',
  'addressDeletedError' => 'Can`t delete these addresses.',
  'xrpTag' => 'XRP Tag!',
  'xrpTagWarning' => 'You can add XRP destination tag by using this format (address:tag). e.g. "%s"',
  'addFunds' => 'Adding funds via EncryptCoin',
  'addFundsAdmin' => 'Adding funds via EncryptCoin (by admin)',

  'status' => 'Status',
  'transactions' => 'Transactions',
  'transactionsCount' => 'TXs',
  'transactionID' => 'Transaction ID',
  'transactionHash' => 'Transaction Hash',
  'transactionDate' => 'Transaction Date',
  'isConfirmed' => 'Is confirmed?',
  'confirmations' => 'Confirmations',
  'setAsConfirmed' => 'Set as Confirmed',
  'setAsConfirmedDescriptions' => 'When you clikc this button, this transaction will be added to the invoice.',
  'transactionDeleted' => 'Transaction was deleted successfully.',
  'transactionDeletedError' => 'Can`t delete this transaction.',

  'activitylog' => 'Activity Log',
  'activitylogDeleted' => 'Activity log was deleted successfully.',
  'activitylogDeletedError' => 'Can`t delete this activitylog.',
  'activitylogCleared' => 'Activity log was cleared successfully.',
  'activitylogClearError' => 'Can`t clear activitylog.',

  'invoice' => 'Invoice',
  'invoiceid' => 'Invoice ID',
  'addedDate' => 'Added Date',
  'remove' => 'Remove',
  'client' => 'Client',
  'txID' => 'TX ID',
  'amount' => 'Amount',
  'receivedAmount' => 'Received Amount',
  'price' => 'Invoice Price',
  'invoicePrice' => 'Invoice Price',
  'receivedPrice' => 'Received Price',
  'viewsCount' => 'Views',
  'currency' => 'Currency',
  'lastUsage' => 'Last Usage',
  'lastView' => 'Last View',
  'delete' => 'Delete',
  'clear' => 'Clear',
  'deleteAll' => 'Delete All',
  'deleteSelected' => 'Delete Selected',
  'add' => 'Add',
  'clickToCopy' => 'Click to copy',
  'warning' => 'Warning!',
  'pages-info' => 'page %u of %u', // %u = current page, %u = number of pages
  'ViewonBlockchainExplorer' => 'View on blockchain explorer',

  'unsupported' => 'We hope you enjoy working with EncryptCoin and if you have any questions, requests or find any bugs, please leave a ticket at our support system',
  'joinUs' => 'Join to our mailing list In order to stay informed about security alerts and important updates, To join our mailing list',

  'currencyNotFound' => 'Can`t find the currency.',
  'cannotUpdateDatabase' => 'Can`t update database table.',

  // Help tab
  'reviewVeryImportant' => 'Your valued feedback will motivate us to improve this product.',
  'clickToKeepFeedback' => 'Click here to keep your feedback.',
  'important' => 'Important Instructions!',
  'donotUseAddresses' => 'DO NOT use the addresses you put here anywhere else, this may cause problems with payments verification.',
  'importantList' => [
    'The address is reserved for the client who is about to pay his invoice for an hour. Therefore, do not enter only one address.',
    'If your currency is other than the common currencies you may run into an exchange rate issue. To fix this problem just add USD currency from Setup → Payments → Currencies and then just add USD.',
    'You can try EncryptCoin without using a real coins. Just get a free testnet coins from any faucet then activate the TestNet Mode.',
  ],
  // Addon -----------------------------------------End//

  //
  // Gateway -----------------------------------------Start//
  // config
  'numberOfConfirmations' => 'Number Of Confirmations',
  'numberOfConfirmationsD' => 'Enter the number of confirmations required to accept the payments.',
  'ExchangeRateMargin' => 'Exchange Rate Margin %',
  'ExchangeRateMarginD' => 'Enter the percentage of exchange rate margin you wish to accept. It is the difference between EncryptCoin exchange rate and the exchange rate offered by the client wallet. (Leave it 1 if you are not sure)',
  'AutoAcceptOrder' => 'Auto Accept Orders',
  'AutoAcceptOrderD' => '(<small style="color:#FF0000;">deparcted</small>) Automatic acceptance of orders when the payment is confirmed.',
  // 'AcceptAnyAmount' => 'Accept over/under payments',
  // 'AcceptAnyAmountD' => 'If the payment is less than the invoice it will be added as down payment, and if it is higher, the surplus will be added to the client balance.',
  'testNet' => 'TestNet Mode',
  'testNetD' => 'Check this box to activate testnet mode (only for testing).',

  // Errors
  'AddressesReservedTitle' => 'All Addresses are Reserved',
  'AddressesReserved' => 'All %s addresses are reserved at this moment. Please come back after a few minutes to complete the payment.',
  'addressesEmptyTitle' => 'The Addresses List is Empty',
  'addressesEmpty' => 'The addresses list is empty. Please contact us or try again after a few minutes.',
  'amountErrorTitle' => 'Amount Error',
  'amountError' => 'There are a problem getting the correct amount. Please contact us or try again after a few minutes.',
  'amountZeroTitle' => 'The Amount is Zero',
  'amountZero' => 'There is an error in the amount of invoice.',

  'PayWith' => 'Pay With',
  'instructions' => 'Instructions',
  'warning' => 'Warning!',
  'TestNetActivated' => 'TestNet mode is acctivated. Testnet coins are separate and distinct from actual coins, and are never supposed to have any value.',
  'paymentSent' => 'Payment was sent but still waiting for confirmations.<br/>If you do not want to wait, you can close this window now!',
  'clickHereToBack' => 'Click here to go back!',
  
  'stillWaitingForPayment' => 'Still waiting for a transaction!',
  'waitTransaction' => 'Don\'t close this box until the transaction is catched...<br/>If it closes down by itself, just reopen it to complete the payment.',

  'paymentReceived' => 'The transaction is catched, waiting for network confirmation. Thank you for the payment.',
  'youCanCloseWindow' => 'You can close this window now.',
  'paymentIsLessAmount' => 'Your payment is less than the amount due, the unpaid amount is (%s %s).',
  'paymentIsMoreAmount' => 'Your payment is more than the amount due, The extra amount (%s %s) will be added to your credit balance.',

  'confirmationsStillBelow' => 'Confirmations are still below the required number of confirmations.',

  'paymentAdded' => '%s added to the invoice, you must pay the remaining due.',
  'creditAdded' => 'Payment confirmed. Your request is being processed.<br/>%s added to your credit balance.',

  'noNeedRefresh' => 'No need to refresh page, your payment status will be updated automatically.',
  'awaitingPayment' => 'Awaiting for %s %s payment...',
  'awaitingConfirmations' => 'Awaiting for confirmations',

  'paymentDescription' => '', // To display any text under list of icons
  'emptyReceptionAddresses' => 'There are no reception addresses.',
  'confirm' => 'Confirm',
  'waitRedirecting' => 'Wait. Redirecting...',
  'errorTryAgain' => 'An error occurred, please try again.',
  'paymentConfirmed' => 'Payment confirmed. Your request is being processed.<br/>You will receive confirmation by email once your payment has been processed.',
  'sendExactAmount' => 'Send the exact amount in one payment, otherwise payment won\'t confirmed',

  'sendOnePayment' => 'Send <strong>%s %s</strong> (%s) in ONE payment'
  // Gateway -----------------------------------------End//
];
