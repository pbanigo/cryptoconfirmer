<?php

namespace EncryptCoin;

! defined( 'WHMCS' ) && die( 'This file cannot be accessed directly' );

/**
 * EncryptCoinForm
 */
class EncryptCoinForm extends EncryptCoin
{

  /**
   * [__construct description]
   *
   * @method __construct
   * @param  array       $info [description]
   */
  function __construct( $info = [], $params = [] ) {
    if ( !is_array( $info ) || empty( $info ) || !is_array($params) || empty($params) ) {
      return;
    }

    if ( isset($info['error']) ) {
      $this->display_error( $info['error'] );
    }

    $info['invoicenum'] = $params['invoicenum'];
    $info['companyname'] = $params['companyname'];
    $info['type'] = $params['type'];
    $info['numberOfConfirmations'] = $params['numberOfConfirmations'];
    $info['prefixedAmount'] = $params['cart']->total->toPrefixed();

    $this->info = $info;
    $this->address = $info['address'];
    $this->sent = isset($info['sent']) && $info['sent'];
    $this->tag = '';
    $this->amount = $info['amount'];
    $this->price = $info['price'];
    $this->original_currency = $info['original_currency'];

    if ( 'XRP' === $info['currency'] )  {
      $this->get_destination_tag();
    }
  }

  /**
   * [get_destination_tag description]
   *
   * @method get_destination_tag
   * @return [type]              [description]
   */
  private function get_destination_tag() {
    $regex = '/^([r][0-9a-zA-Z]{24,34}){1}(:)?([0-9]{9,})?$/';
    $address_regex = '/^[r][0-9a-zA-Z]{24,34}$/';
    $tag_regex = '/^[0-9]{9,}$/';
    $xrp = preg_match( $regex, $this->address, $address );
    if (
      ! $xrp ||
      ! is_array($address) ||
      empty($address) ||
      ! $address[1] ||
      ! $address[3] ||
      !preg_match( $address_regex, $address[1]) ||
      !preg_match( $tag_regex, $address[3] )
    ) {
      return;
    }
    $this->address = $address[1];
    $this->tag = $address[3];
  }

  /**
   * { function_description }
   */
  private function display_error( $error ) {
    $coin = parent::post_attr( 'encryptcoin' );
    $name = parent::$_currencies[$coin]['name'];
    $slug = parent::$_currencies[$coin]['slug'];
    $content = '';
    $lang = self::$_lang;

    if ( 'addresses_are_reserved' === $error ) {
      $title = $lang['AddressesReservedTitle'];
      $content = sprintf( $lang['AddressesReserved'], $name );
    } elseif ( 'addresses_are_empty' === $error ) {
      $title = $lang['addressesEmptyTitle'];
      $content = $lang['addressesEmpty'];
    } elseif ( 'amount' === $error ) {
      $title = $lang['amountErrorTitle'];
      $content = $lang['amountError'];
    } elseif ( 'amount_is_zero' === $error ) {
      $title = $lang['amountZeroTitle'];
      $content = $lang['amountZero'];
    }

    $html = '
      <div class="encryptcoin-error-message">
        <div class="encryptcoin-modal__body__ribbon">
          <span class="' . $slug . '">'.$coin.'</span>
        </div>
        <div class="encryptcoin-error-message__content">
          <img width="100" height="100" src="modules/addons/encryptcoin/assets/images/warning.svg"/>
            <h2>'.$title.'</h2>
            <div>' . $content . '</div>
        </div>
      </div>
    ';

    $output = [
      'content' => $html,
      'status' => 'error'
    ];

    $josn = json_encode($output);
    header("Content-Type: application/json; charset=utf8");
    echo $josn;
    exit();
  }

  /**
   * { function_description }
   *
   * @return     boolean  ( description_of_the_return_value )
   */
  public function html() {

    if ( parent::post_attr('encryptcoin') ) {
      $this->popup();
    }

    $lang = self::$_lang;
    $v = self::$version;

    $test_net = $this->test_net();

    $description = !empty($test_net) || !empty($lang['paymentDescription']) ?
      '<div class="encryptcoin-description">
        <small>' . $lang['paymentDescription'] . '</small>
        ' . $test_net . '
      </div>'
      : '';

    return <<<HTML
      <link href="modules/addons/encryptcoin/assets/css/gateway.min.css?v={$v}" rel="stylesheet"/>
      <div id="encryptcoin">
        {$description}
        <div class="encryptcoin-icons">
          {$this->icons()}
        </div>

        <div id="encryptcoin-modal" class="encryptcoin-modal">
          <div class="encryptcoin-modal__body">
            <div id="encryptcoin-modal-content" class="encryptcoin-modal__body__content"><div class="empty-modal"></div></div>
            <a class="encryptcoin-modal__body__close" href="#"></a>
          </div>
        </div>

      </div>
      <script src="modules/addons/encryptcoin/assets/vendor/davidshimjs-qrcodejs/qrcode.min.js"></script>
      <script src="modules/addons/encryptcoin/assets/js/gateway.min.js?v={$v}"></script>
HTML;
  }

  /**
   * [test_net description]
   *
   * @method test_net
   * @return [type]   [description]
   */
  private function test_net() {
    $invoiceid = self::get_attr('id');
    return true === parent::$testnet && $invoiceid ? '<div class="encryptcoin-addresses-error">' . self::$_lang['TestNetActivated'] . '</div>' : '';
  }

  /**
   * { function_description }
   *
   * @param      <type>  $lang   The language
   */
  private function popup() {
    $output                   = [];
    $tag                      = '';

    $company                  = $this->info['companyname'];
    $type                     = $this->info['type'];
    $invoicenum               = $this->info['invoicenum'];
    $numberOfConfirmations    = $this->info['numberOfConfirmations'];
    $prefixedAmount           = $this->info['prefixedAmount'];
    $blur                     = $this->sent ? ' encryptcoin-blure' : '';
    $amount                   = (string) number_format( $this->amount, 8 );
    $confirmations            = isset($this->info['confirmations']) ? (int) $this->info['confirmations'] : 0;
    $lang                     = self::$_lang;
    $code                     = parent::post_attr('encryptcoin');
    $invoiceid                = parent::post_attr('id');
    $slug                     = self::$_currencies[$code]['slug'];
    $name                     = self::$_currencies[$code]['name'];
    $before_input             = $code === 'ETH' ?  '<span class="before_input">0x</span>' : '';
    $test                     = parent::$testnet ? '1' : '0';
    $note                     = sprintf( $lang['sendOnePayment'], $amount, $code , $prefixedAmount );
    $awaitingPayment          = sprintf( $lang['awaitingPayment'], $amount, $name );
    $sendExactAmount          = $lang['sendExactAmount'] && false ? '<span class="encryptcoin-payment-info__address__amount__warning">' . $lang['sendExactAmount'] . '</span><br/>' : '';
    $message                  = $this->sent ? $lang['paymentReceived'] . '<br/>' . $lang['youCanCloseWindow'] : $lang['waitTransaction'];
    $waiting_payment          = $this->sent ? 'done' : '';

    if ( ! empty($this->tag) ) {
      $tag = <<<HTML
        <nobr>
          <label for="encryptcoin-tag">{$lang['destinationTag']}: </label>
          <input id="encryptcoin-tag" class="tag" type="text" value="{$this->tag}" readonly/>
          <span data-copy="encryptcoin-tag" class="encryptcoin-click-to-copy">
            <img width="15" height="15" src="modules/addons/encryptcoin/assets/images/copy.svg"/>
          </span>
        </nobr>
HTML;
    }

    $address = $this->sent ? str_repeat("xX", 20) : $this->address;
    $qrcode_data = $this->get_url_data( $address, $invoiceid, $slug );

    $output['content'] = <<<HTML
      <div class="encryptcoin-modal__body__content__container {$slug}">
        <div class="encryptcoin-modal__body__ribbon">
          <span class="{$slug}">{$code}</span>
        </div>
        <h2>
          <img  src="modules/addons/encryptcoin/assets/images/icons/{$slug}.svg"/>
          {$note}
        </h2>
        <div class="encryptcoin-payment-info-container">
          <div class="encryptcoin-payment-row">
            <div class="encryptcoin-payment-column qrcode{$blur}">
              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 45 45" style="max-height: 300px;">
                <g id="encryptcoin-qrcode" data-qrdata="{$qrcode_data}"/>
              </svg>
            </div>
            <div class="encryptcoin-payment-column info">
              <div class="encryptcoin-payment-info">
                <div class="encryptcoin-payment-info__address{$blur}">
                  {$sendExactAmount}
                  <h3>{$company} <strong>{$type}</strong> #$invoicenum</h3>
                  <nobr>
                    <label for="encryptcoin-address">{$lang['address']}: </label>
                    <input id="encryptcoin-address" class="address" type="text" value="{$address}" readonly/>
                    <span title="{$lang['clickToCopy']}" data-copy="encryptcoin-address" class="encryptcoin-click-to-copy">
                      <img width="15" height="15" src="modules/addons/encryptcoin/assets/images/copy.svg"/>
                    </span>
                  </nobr>
                  {$tag}
                  <div class="encryptcoin-payment-info__address__amount">
                    <nobr>
                      <label for="encryptcoin-amount">{$lang['amount']} ({$code}): </label>
                      <input id="encryptcoin-amount" class="amount" type="text" value="{$amount}" readonly/>
                      <span data-copy="encryptcoin-amount" class="encryptcoin-click-to-copy">
                        <img width="15" height="15" src="modules/addons/encryptcoin/assets/images/copy.svg"/>
                      </span><br/>
                    </nobr>
                    <nobr><label>{$lang['amount']} ({$this->original_currency}):</label> <strong>{$this->price}</strong></nobr><br/>
                  </div>
                  <hr/>
                </div>
                <div class="encryptcoin-auto-confirm-amount">
                  {$lang['noNeedRefresh']}
                  <ol>
                    <li id="encryptcoin-waiting-payment" class="{$waiting_payment}">{$awaitingPayment}</li>
                    <li id="encryptcoin-waiting-confirmation"><span>{$lang['awaitingConfirmations']} (<span id="encryptcoin-confirmations-count">{$confirmations}</span>/{$numberOfConfirmations})...</span></li>
                  </ol>
                  <div id="encryptcoin-confirmation-status">
                    {$message}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
HTML;

    $output['status'] = 'success';
    $josn = json_encode($output);
    header("Content-Type: application/json; charset=utf8");
    echo $josn;
    exit();
  }

  /**
   * Gets the url data.
   *
   * @param      <type>  $invoiceid  The invoiceid
   * @param      string  $slug       The slug
   *
   * @return     string  The url data.
   */
  private function get_url_data( $address, $invoiceid, $slug ) {
    $amount = (string) number_format( $this->amount, 8 );
    $tag = empty( $this->tag ) ? '' : '?dt=' . $this->tag;
    $i = empty( $tag ) ? '?' : '&';
    return $slug . ':' . $address . $tag . $i . 'amount=' . $amount;
  }

  /**
   * { function_description }
   *
   * @return     string  ( description_of_the_return_value )
   */
  private function icons() {
    $output = $pay = $class = $single = '';
    $invoiceid = self::get_attr('id');
    $lang = self::$_lang;

    if ( ! empty( self::$gateway ) && ! empty( $invoiceid ) ) {
      $_c = self::$_currencies;
      if ( count(self::$gateway) === 1 ) {
        $pay = ' ' . $lang['PayWith'] . ' ' . $_c[self::$gateway[0]]['name'];
        $single = ' data-single="true"';
      }
      foreach ( self::$gateway as $key => $value ) {
        $output .= '<a href="#' . $_c[$value]['slug'] . '" data-title="' . $_c[$value]['name'] . '" class="' . $value . '"'.$single.'><img src="modules/addons/encryptcoin/assets/images/icons/' . $_c[$value]['slug'] . '.svg" style="width:27px"/>'.$pay.'</a>';
      }
    } else if ( empty( $invoiceid ) ) {
      $output = '<div class="encryptcoin-addresses-error">' . $lang['waitRedirecting'] . '</div>';
    } else {
      $output = '<div class="encryptcoin-addresses-error">' . $lang['emptyReceptionAddresses'] . '</div>';
    }
    return $output;
  }

}
