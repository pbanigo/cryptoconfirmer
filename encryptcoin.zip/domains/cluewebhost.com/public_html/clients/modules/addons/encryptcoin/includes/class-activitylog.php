<?php
/**
 * EncryptCoin is a real peer-to-peer payment gateway for WHMCS which allows you to accept cryptocurrency payments
 * without transaction fees, monthly fee or bank account
 *
 * @author     ZintaThemes
 * @package   EncryptCoin
 * @since     1.0
 * @version   1.0.1
 */

! defined ( "WHMCS" ) && die ( "This file cannot be accessed directly" );

use WHMCS\Database\Capsule;

/**
 * Main class of encryptCoinAdmin addon, this class will be call in admin page only
 *
 * @access     public
 * @author     Zinta
 * @since     1.0
 * @version   1.0
 */
if ( ! class_exists ( 'encryptCoinActivitylog' ) ) {

  class encryptCoinActivitylog extends encryptCoinInit
  {

    /**
     * [private description]
     *
     * @var array
     */
    private $vars = [];

    /**
     * [private description]
     *
     * @var string
     */
    private static $msg = '';

    /**
     * [private description]
     *
     * @var string
     */
    private static $state = 'success';

    /**
     * [private description]
     *
     * @var int
     */
    private $per_page = 40;

    /**
     * [private description]
     *
     * @var int
     */
    private $num_pages = 1;

    /**
     * Construct function
     *
     * @access     public
     * @author     zinta
     * @return     mixed
     * @since     1.0
     * @version   1.0.0
     */
    public function __construct() {
      $this->activitylog_list();
    }

    /**
     * [list description]
     *
     * @method list
     * @param  string $search [description]
     * @return [type]         [description]
     */
    private function activitylog_list() {
      $search = ( string ) self::$helper->_get('s');
      $filter = ( string ) self::$helper->_get('filter');
      $page   = ( integer ) self::$helper->_get('page');

      try {
        $list = Capsule::table( 'encryptcoin_activitylog' );

        $list = $list->orderBy( 'date', 'desc' );

        if ( ! empty( $search ) ) {
          $list = $list->where( 'address', 'like', "%{$search}%" );
        }

        if ( ! empty( $filter ) && 'clear' !== $filter ) {
          $list = $list->where( 'code', '=', $filter );
        }

        $list = $this->count( $list, $page );

        $this->get_list(
          $list->get()
        );

      } catch ( Exception $e ) {
        $this->msg = 'ERROR11: ' . $e->getMessage();
        $this->state = 'danger';
      }

      exit();
    }

    /**
     * [count description]
     *
     * @method count
     * @param  [type] $list [description]
     * @return [type]       [description]
     */
    private function count( $list, $page ) {
      $count = $list->count('id');
      if ( $count > $this->per_page ) {
        $this->num_pages = ceil( $count / $this->per_page );
        if ( $page > $this->num_pages ) {
          $page = $this->num_pages;
        } elseif ( $page < 1 ) {
          $page = 1;
        }
        $this->num_pages > 1 && $this->pages( $page );
        $list = $list->skip( ( $page - 1 ) * $this->per_page )->take( $this->per_page );
      }
      return $list;
    }

    /**
     * [delete description]
     *
     * @method delete
     * @param  [type] $delete [description]
     * @return [type]         [description]
     */
    private function clear() {
      $date = ( new \DateTime( "-7 days" ) )->format('Y-m-d H:i:s');

      try {
        if ( $delete = Capsule::table( 'encryptcoin_activitylog' )->whereDate( 'date', '<', $date )->delete() ) {
          self::$msg = self::$lang['activitylogCleared'];
        } else {
          self::$msg = self::$lang['activitylogClearError'];
          self::$state = 'danger';
        }
      } catch ( Exception $e ) {
        self::$msg = self::$lang['activitylogClearError'] . ': ' . $e->getMessage();
        self::$state = 'danger';
      }
    }

    /**
     * [delete description]
     *
     * @method delete
     * @param  [type] $delete [description]
     * @return [type]         [description]
     */
    private function delete_selected( $delete = [] ) {
      if ( empty( $delete ) ) {
        return;
      }

      try {
        foreach ( $delete as $id ) {
          if ( $delete = Capsule::table( 'encryptcoin_activitylog' )->where( 'id', '=', $id )->delete() ) {
            self::$msg = self::$lang['activitylogDeleted'];
          } else {
            self::$msg = self::$lang['activitylogDeletedError'];
            self::$state = 'danger';
          }
        }
      } catch ( Exception $e ) {
        self::$msg = self::$lang['activitylogDeletedError'] . ': ' . $e->getMessage();
        self::$state = 'danger';
      }
    }

    /**
     * [get_list description]
     *
     * @method get_list
     * @param  [type]   $info    [description]
     * @param  [type]   $address [description]
     * @return [type]            [description]
     */
    private static function get_list( $activitylogs = [] ) {
      foreach ( $activitylogs as $activitylog ) {
        self::content( $activitylog );
      }
    }

    /**
     * [content description]
     *
     * @method content
     * @param  [type]  $info    [description]
     * @param  [type]  $address [description]
     * @return [type]           [description]
     */
    private static function content( $activitylog = [] ) {
      $client = self::get_client( $activitylog->invoiceid );
      $lang = self::$lang;

      $amount = !class_exists( 'encryptCoinDetails' ) ? '' : '';

      $amount = class_exists( 'encryptCoinDetails' ) ? encryptCoinDetails::activitylog_amount(
        $activitylog->currency,
        $activitylog->amount,
        $activitylog->original_currency,
        $activitylog->price
      ) : '';

      echo<<<HTML
      <tr>
        <td class="text-center">
          <input type="checkbox" class="activitylog-form-checkbox" name="delete-this[{$activitylog->id}]" value="{$activitylog->id}"/>
        </td>
        <td class="fieldarea">
          {$activitylog->id}
        </td>
        <td class="fieldarea">
          <a href="invoices.php?action=edit&id={$activitylog->invoiceid}">
            {$activitylog->invoiceid}
          </a>
        </td>
        <td class="fieldarea">
          <a href="clientssummary.php?userid={$client['id']}">
            {$client['name']}
          </a>
        </td>
        <td class="fieldarea">
          <code>{$activitylog->address}</code>
          <!-- <a href="https://blockchair.com/search/?q={$activitylog->address}" target="_blank" title="{$lang['ViewonBlockchainExplorer']}">
            <i class="fa fa-external-link-alt"></i>
          </a> -->
        </td>
        {$amount}
        <td class="fieldarea">
          {$activitylog->date}
        </td>
      </tr>
HTML;
    }

    /**
     * [list description]
     *
     * @method list
     * @return [type]       [description]
     */
    public static function activitylog_view() {
      $lang = self::$lang;

      if ( ( string ) self::$helper->_post('clear') === 'clear' ) {
        self::clear();
      }

      if ( ( string ) self::$helper->_post('delete-selected') === 'delete' ) {
        self::delete_selected(
          self::$helper->_post('delete-this')
        );
      }

      $amount = class_exists( 'encryptCoinDetails' ) ? '<th class="added-date">' . $lang['amount'] . '</th>' : '';

      $message = self::message();
      
      $active = class_exists('encryptCoinTransactions') ? '' : ' active';

      echo <<<HTML
      <div id="tab1" class="tab-pane{$active}">
        <form method="post" id="activitylog-form">
          <table class="form" width="100%" cellspacing="2" cellpadding="3" border="0">
            <tbody>
              <tr>
                <td class="encryptcoin-toolbar">
                  <!--
                  <input id="encryptcoin-activitylog-toolbar-search" type="text" name="" placeholder="Search">
                  <span></span>
                  <a href="#" class="encryptcoin-activitylog-toolbar-fliter-currencies" data-title="{$lang['clear']}"  data-code="clear"><i class="fa fa-trash-alt"></i></a>
                  -->

                  <a href="#" id="encryptcoin-activitylog-toolbar-refresh" class="pull-right"><i class="fa fa-sync"></i></a>
                  <span class="pull-right"></span>
                  <a href="#" class="encryptcoin-activitylog-toolbar-pages pull-right" data-pages="next" title="Next"><i class="fa fa-angle-right"></i></a>
                  <a href="#" class="encryptcoin-activitylog-toolbar-pages pull-right" data-pages="previous" title="Previous"><i class="fa fa-angle-left"></i></a>
                  <span class="pull-right"></span>
                  <button type="submit" class="btn btn-danger btn-sm confirmed-button pull-right" name="clear" value="clear"><i class="fa fa-trash-alt"></i> {$lang['clear']}</button>
                  <button type="submit" class="btn btn-danger btn-sm confirmed-button pull-right" name="delete-selected" value="delete"><i class="fa fa-trash-alt"></i> {$lang['deleteSelected']}</button>
                </td>
              </tr>
            </tbody>
          </table>
          {$message}
          <table class="activitylog-list-table datatable" width="100%" cellspacing="2" cellpadding="3" border="0">
            <thead>
              <tr>
                <th class="addresses-list-table__currency"><input class="activitylog-form-selectall" type="checkbox" name="selectall" value="all"/></th>
                <th class="added-date">{$lang['id']}</th>
                <th class="added-date">{$lang['invoiceid']}</th>
                <th class="added-date">{$lang['client']}</th>
                <th class="added-date">{$lang['address']}</th>
                {$amount}
                <th class="added-date">{$lang['date']}</th>
              </tr>
            </thead>
            <tbody id="activitylog-list"></tbody>
          </table>
        </form>
      </div>
HTML;
    }

    /**
     * Gets the client.
     *
     * @param      string  $invoiceid  The invoiceid
     *
     * @return     string  The client.
     */
    private static function get_client( $invoiceid = '' ) {
      if ( ! $invoiceid ) {
        return;
      }

      $client = [];
      try {
        $userid = ( string ) Capsule::table('tblinvoices')->where( 'id', '=', $invoiceid )->value( 'userid' );
        $client_r = ( array ) Capsule::table('tblclients')->where( 'id', '=', $userid )->first( [ 'id', 'firstname', 'lastname' ] );
        $client['id'] = $client_r['id'];
        $client['name'] = $client_r['firstname'] . ' ' . $client_r['lastname'];
      } catch ( Exception $e ) {
        $message = 'ERROR10: ' . $e->getMessage();
        $state = 'danger';
      }
      return $client;
    }

    /**
     * [pages description]
     *
     * @method pages
     * @param  string $value [description]
     * @return [type]        [description]
     */
    private function pages( $page = 0 ) {
      echo '<tr><td id="encryptcoin-activitylog-numpages" class="fieldarea" colspan="10" data-numpages="' . $num_pages . '">' . sprintf( self::$lang['pages-info'], $page, $this->num_pages ) . '</td></tr>';
    }

    /**
     * [message description]
     *
     * @method message
     * @param  [type]  $m [description]
     * @return [type]     [description]
     */
    private static function message() {
      $msg = self::$msg;
      $state = self::$state;

      if ( empty( $msg ) ) {
        return '';
      }

      return <<<HTML
      <tr>
        <td class="fieldarea" colspan="10">
          <div class="panel panel-health-check panel-health-check-{$state}">
            <div class="panel-heading"><small>{$msg}</small></div>
          </div>
        </td>
      </tr>
HTML;
    }
  }
}
