<?php

namespace EncryptCoin;

/**
 *
 */
class EncryptCoinConverter extends EncryptCoin
{

  /**
   * [private description]
   *
   * @var [type]
   */
  public $amount = 0.000;

  /**
   * { var_description }
   *
   * @var        boolean
   */
  private $reverse = false;
  
  /**
   * type
   *
   * @var string
   */
  private $type = 'BTC';

  /**
   * [__construct description]
   *
   * @method __construct
   * @param  integer     $price   [description]
   * @param  string      $original_currency [description]
   */
  function __construct( $price = 0, $original_currency = 'USD', $reverse = false ) {
    $this->reverse = $reverse;
    $this->type    = parent::post_attr('encryptcoin');

    if ( 'USD' !== $original_currency ) {
      $rate = $this->get_currency( $original_currency );

      $price = number_format(
        $reverse ? $price * $rate : $price / $rate
      , 5 );
    }

    return $this->amount = 'USDT' === $this->type ? $price : $this->amount( $price, $original_currency );
  }

  /**
   * Method get_currency
   *
   * @param $original_currency $original_currency [explicite description]
   *
   * @return void
   */
  private function get_currency( $original_currency ) {
    $rate         = 0.00;
    $exchangerate = EncryptCoin::get_content( 'https://api.exchangerate.host/latest?base=USD' );
    if ( !empty( $exchangerate ) && isset($exchangerate['rates']) && is_array($exchangerate['rates']) ) {
      $rate = isset($exchangerate['rates'][$original_currency]) ? $exchangerate['rates'][$original_currency] : 0.00;
    }
    if ( $rate <= 0.000000001 ) {
      $exchangerate = EncryptCoin::get_content( 'https://api.exchangeratesapi.io/latest?base=USD' );
      if ( !empty( $exchangerate ) && isset($exchangerate['rates']) && is_array($exchangerate['rates']) ) {
        $rate = isset($exchangerate['rates'][$original_currency]) ? $exchangerate['rates'][$original_currency] : 0.00;
      }
    }
    return $rate;
  }

  /**
   * [auto description]
   *
   * @method auto
   * @param  [type] $price             [description]
   * @param  [type] $original_currency [description]
   * @return [type]                    [description]
   */
  private function amount( $price, $original_currency ) {
    if ( ! $rate = $this->cryptonator() ) {
      $rate = $this->exchangerate();
    }

    if ( $rate && 'double' === gettype( $rate ) ) {
      $amount = ! $this->reverse ? $price / $rate : $price * $rate;
    }
    return isset($amount) && !empty($amount) ? round($amount, 8) : false;
  }
  
  /**
   * Method cryptonator
   *
   * @param $price $price [explicite description]
   *
   * @return void
   */
  private function cryptonator() {
    $rate = 0.00;

    $url = "https://api.cryptonator.com/api/ticker/{$this->type}-USD/";
    if ( $array = EncryptCoin::get_content( $url ) ) {
      $rate = isset($array['ticker']) && isset($array['ticker']['price']) ? ( float ) $array['ticker']['price'] : 0.00;
    }
    return $rate;
  }
  
  /**
   * Method exchangerate
   *
   * @param $price $price [explicite description]
   *
   * @return void
   */
  private function exchangerate() {
    $rate = 0.00;
    $url = "https://api.exchangerate.host/convert?from={$this->type}&to=USD";
    if ( $array = EncryptCoin::get_content( $url ) ) {
      $rate = isset($array['info']) && isset($array['info']['rate']) ? ( float ) $array['info']['rate'] : 0.00;
    }
    return $rate;
  }
}
