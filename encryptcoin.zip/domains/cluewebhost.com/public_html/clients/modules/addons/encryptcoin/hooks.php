<?php
/**
 * EncryptCoin is a real peer-to-peer payment gateway for WHMCS which allows you to accept cryptocurrency payments
 * without transaction fees, monthly fee or bank account
 *
 * @package EncryptCoin
 * @author ZintaThemes
 * @version 4.1.3
 * @link https://zintathemes.com
 *
 */

if (! defined ( 'WHMCS' )) die ( 'This file cannot be accessed directly' );

/**
 * Automation hook
 * 
 */
add_hook('PreAutomationTask', 1, function( $vars ) {
  $file = dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'gateway' . DIRECTORY_SEPARATOR . 'class-automation.php';

  if ( file_exists( $file ) ) {
  	require_once $file;
  	new \EncryptCoin\EncryptCoinAutomation();
  }
});
