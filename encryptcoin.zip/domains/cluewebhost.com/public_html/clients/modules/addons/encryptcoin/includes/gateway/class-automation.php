<?php

namespace EncryptCoin;


! defined("WHMCS") && die("This file cannot be accessed directly");


use WHMCS\Database\Capsule as Capsule;


/**
 *
 */
class EncryptCoinAutomation
{

  /**
   * Constructs a new instance.
   *
   * @return     boolean  ( description_of_the_return_value )
   */
  function __construct() {
    $date = ( new \DateTime( "-2 days" ) )->format('Y-m-d H:i:s');

    try {
      $transactions = Capsule::table( 'encryptcoin_transactions' )->where( 'confirmed', '=', '0' )->whereDate( 'date', '>', $date )->get();

      if ( empty( $transactions )) {
        return;
      }

      require_once dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'class-transaction.php';

      $params = $this->get_conf();
      $margin = (float) abs($params['ExchangeRateMargin']);
      $margin = $margin <= 5 ? $margin: 1;

      foreach ( $transactions as $key => $value ) {
        $tx = (array) $value;
        $array = $tx + [
          'margin' => $tx['amount'] * $margin / 100
        ];
        ( new EncryptCoinTransaction( $array, $params, true ) )->txs;
      }

    } catch ( Exception $e ) {
      return;
    }
  }

  /**
   * Gets the conf.
   *
   * @return     array  The variables.
   */
  private function get_conf() {
    require_once ROOTDIR . '/includes/gatewayfunctions.php';

    if ( function_exists('getGatewayVariables') ) {
      $params = getGatewayVariables('encryptcoin');
      return [
        'AutoAcceptOrder'       => 'on' === $params['AutoAcceptOrder'],
        'testNet'               => 'on' === $params['testNet'],
        'numberOfConfirmations' => (int) $params['numberOfConfirmations'],
        'ExchangeRateMargin'    => (float) $params['ExchangeRateMargin'],
      ];
    } else {
      return $params = $this->get_conf_db();
    }

  }

  /**
   *
   * Gets the testnet.
   *
   * @return     boolean|string  The testnet.
   */
  private function get_conf_db() {
    $output = [];

    try {
      $conf = Capsule::table( 'tblpaymentgateways' )->where( 'gateway', '=', 'encryptcoin' )->get([ 'setting', 'value' ]);
      if ( is_array($conf) && !empty($conf) ) {
        foreach ( $conf as $key => $value ) {
          if ( in_array( $value->setting, [ 'AutoAcceptOrder', 'testNet' ] ) ) {
            $output[$value->setting] = 'on' === $value->value;
          } elseif ( 'numberOfConfirmations' === $value->setting ) {
            $output['numberOfConfirmations'] = (int) $value->value;
          } elseif ( 'ExchangeRateMargin' === $value->setting ) {
            $output['ExchangeRateMargin'] = (float) $value->value;
          }
        }
      }
    } catch ( Exception $e ) {
      return;
    }
    return $output;
  }

}
