<?php

namespace EncryptCoin;

! defined('WHMCS') && die('This file cannot be accessed directly');

use WHMCS\Database\Capsule as Capsule;

/**
 *
 */
class EncryptCoinTransaction
{

  /**
   * { var_description }
   *
   * @var        array
   */
  public $txs = [];

  /**
   * [private description]
   *
   * @var [type]
   */
  private $info = [];

  /**
   * { var_description }
   *
   * @var        array
   */
  private static $lang = [];

  /**
   * { var_description }
   *
   * @var        string
   */
  private $api = 'https://zintathemes.com/api/';

  /**
   * Constructs a new instance.
   *
   * @param      array    $info    The information
   * @param      array    $params  The parameters
   * @param      boolean  $auto    The automatic
   */
  function __construct( $info = [], $params = [], $auto = false ) {
    if ( !is_array( $info ) || empty( $info ) || $info['amount'] <= 0.000000001 ) {
      exit('ERROR TRANSACTION');
    }

    $this->info = $info;

    $this->txs  = $this->get_data([ 'address' => $info['address'], 'hash' => isset($info['hash']) ? $info['hash'] : '', 'amount' => $info['amount'], 'currency' => $info['currency'], 'price' => $info['price'], 'original_currency' => $info['original_currency'], 'testnet' => $params['testNet'] === true, 'pr' => $this->get_pr(), 'auto' => $auto, 's' => '0' ]);

    self::$lang = $params['lang'];

    $output     = [
      'status' => 'waiting',
      'message' => self::$lang['stillWaitingForPayment'] . '<br/>' . self::$lang['waitTransaction'],
      'confirmations' => 0
    ];

    if ( ! empty( $this->txs ) && isset($this->txs['statues']) && $this->txs['statues'] === 'success' ) {
      $result = isset( $info['hash'] ) && ! empty( $info['hash'] ) ? $this->payment_confirmation( $params ) : $this->get_transaction( $params );
      $output = (array) $result + (array) $output;
    }

    if ( $auto === false ) {
      $this->output( $output );
    }
  }

  /**
   * [get_content description]
   *
   * @method get_content
   * @param  string      $url [description]
   * @return [type]           [description]
   */
  protected function get_data( $data ) {
    if ( ! function_exists('curl_version') ) {
      return false;
    }
    $url = $this->api . '?api=encryptcoin&' . http_build_query( $data, '', '&');

    $ch = curl_init();
    curl_setopt_array( $ch, [ CURLOPT_URL => $url, CURLOPT_TIMEOUT => 60, CURLOPT_RETURNTRANSFER => true, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_SSL_VERIFYPEER => 0 ] );

    $response = curl_exec($ch);
    curl_close($ch);
    $response = json_decode( $response, true );

    return is_array( $response ) && !empty( $response ) && $response['statues'] === 'success' ? $response : [];
  }

  /**
   * { function_description }
   *
   * @param      <type>  $params  The parameters
   */
  private function get_transaction( $params ) {
    $data           = $this->info;
    $tx             = $this->txs;
    $margin         = (double) $data['margin'];
    $date           = ( new \DateTime() )->format('Y-m-d H:i:s');
    $requireed      = (int) abs( $params['numberOfConfirmations'] );
    $confirmations  = (int) abs( $tx['confirmations'] );
    $confirmed      = $confirmations >= $requireed || $confirmations > 10;


    $received_price = $data['price'];
    $return     = [
      'status' => 'sent',
      'message' => self::$lang['paymentReceived'] . '<br/>' . self::$lang['youCanCloseWindow'],
      'confirmations' => $confirmations
    ];

    unset( $data['id'], $data['margin'] );

    $deff = $this->txs['total'] - $data['amount'];
    if ( abs($deff) > $margin ) {
      $received_price = round(
        $this->get_deff_amount( $this->txs['total'], $this->info['original_currency'] )
      , 2);
    }

    $data = [
      'hash' => $tx['hash'],
      'amount' => $data['amount'],
      'received_amount' => $tx['total'],
      'price' => $data['price'],
      'received_price' => $received_price,
      'transid' => strtoupper( substr( $tx['hash'], 0, 15 ) ),
      'confirmations' => $confirmations,
      'confirmed' => $confirmed, // TODO: return it to 0
      'date' => $date
    ] + $data;

    try {

      $check = ( array ) Capsule::table( 'encryptcoin_transactions' )->where( 'hash', '=', $tx['hash'] )->first();

      if ( !is_array($check) || empty($check) ) {
        Capsule::table( 'encryptcoin_transactions' )->insert( $data );
        $details = Capsule::table('encryptcoin_addresses')->where( 'address', '=', $data['address'] )->first( [ 'transactions' ] );

        Capsule::table( 'encryptcoin_addresses' )->where( 'address', $data['address'] )->where( 'code', $data['currency'] )->update([
          'transactions' => ++$details->transactions,
          'last_usage' => $date
        ]);

        if ( $confirmed ) {
          $this->info = $data;
          $return = $this->payment_confirmation( $params );
        } elseif ( abs($deff) > $margin ) {
          $amount = abs($received_price - $data['price']);
          if ( $deff < 0.000000001 ) {
            $return['message'] = self::$lang['paymentReceived'] . '<br/><span class="encryptcoin-payment-warning">' . sprintf(self::$lang['paymentIsLessAmount'], $this->info['original_currency'], $amount) . '</span><br/>' . self::$lang['youCanCloseWindow'];
          } else {
            $return['message'] = self::$lang['paymentReceived'] . '<br/><span class="encryptcoin-payment-success">' . sprintf(self::$lang['paymentIsMoreAmount'], $this->info['original_currency'], $amount) . '</span><br/>' . self::$lang['youCanCloseWindow'];
          }
        }
      }

    } catch ( Exception $e ) {
      echo $e->getMessage();
    }

    return $return;
  }

  /**
   * Gets the deff amount.
   *
   * @return     string  The deff amount.
   */
  private function get_deff_amount( $deff, $currency ) {
    return (string) number_format( (new EncryptCoinConverter( $deff, $currency, true ))->amount , 8 );
  }

  /**
   * [confirm description]
   *
   * @method confirm
   * @return [type]  [description]
   */
  private function payment_confirmation( $params ) {

    $requireed      = (int) abs( $params['numberOfConfirmations'] );
    $confirmations  = (int) abs( $this->txs['confirmations'] );
    $confirmed      = $confirmations >= $requireed || $confirmations > 10;

    $return         = [
      'status' => 'sent',
      'message' => self::$lang['paymentReceived'] . '<br/>' . self::$lang['youCanCloseWindow'],
      'confirmations' => $confirmations
    ];

    $this->update_tx( $confirmed );

    if ( $confirmed ) {
      $deff_price = $this->info['received_price'] - $this->info['price'];
      $return['status'] = 'confirmed';

      $this->add_payment();

      $params['AutoAcceptOrder'] && $this->accept_orders( $this->info['invoiceid'] );

      if ( $deff_price > 0 ) {
        $return['message'] = sprintf( self::$lang['creditAdded'], abs($deff_price) . ' ' . $this->info['original_currency'] );
      } elseif ( $deff_price < 0 ) {
        $return['message'] = sprintf( self::$lang['paymentAdded'], abs($this->info['received_price']) . ' ' . $this->info['original_currency'] );
      } else {
        $return['message'] = self::$lang['paymentConfirmed'];
      }

    } elseif ( $confirmations > 0 ) {
      $return['status'] = 'confirm';
      $return['message'] = self::$lang['confirmationsStillBelow'] . '<br/>' . self::$lang['youCanCloseWindow'];
    }

    return $return;
  }

  /**
   * Adds a payment.
   *
   * @param      <type>  $invoiceid  The invoiceid
   * @param      <type>  $amount     The amount
   *
   * @return     <type>  ( description_of_the_return_value )
   */
  private function add_payment() {
    $data = $this->info;
    $invoice = $results = localAPI( 'GetInvoice', [ 'invoiceid' => $data['invoiceid'] ] );

    if ( is_array($invoice) && isset( $invoice['status'] ) && strtolower($invoice['status']) === 'unpaid' ) {
      return localAPI( 'AddInvoicePayment', [
        'invoiceid' => $data['invoiceid'],
        'transid' => $data['transid'],
        'date' => $data['received'],
        'amount' => $data['received_price']
      ]);
    }

  }

  /**
   * { function_description }
   */
  private function update_tx( $confirmed = false ) {
    return Capsule::table( 'encryptcoin_transactions' )->where( 'hash', $this->info['hash'] )->update( [
      'confirmations' => $this->txs['confirmations'],
      'confirmed' => $confirmed
    ]);
  }

  /**
   * { function_description }
   *
   * @param      <type>  $invoiceid  The invoiceid
   *
   * @return     <type>  ( description_of_the_return_value )
   */
  private function accept_orders( $invoiceid ) {
    $invoice = $results = localAPI( 'GetInvoice', [ 'invoiceid' => $invoiceid ] );

    if ( is_array($invoice) && isset( $invoice['status'] ) && strtolower($invoice['status']) === 'paid' ) {
      $orders = $this->get_orders( $invoiceid );
      foreach ( $orders as $key => $value ) {
        $value = (array) $value;
        $order = isset($value[0]) ? (array) $value[0] : $value;
        $result = localAPI( 'AcceptOrder', [ 'orderid' => $order['id'] ] );
      }
    }

  }

  /**
   * Gets the orders.
   *
   * @param      <type>  $invoiceid  The invoiceid
   */
  private function get_orders( $invoiceid ) {
    $orders = [];
    try {
      $orders = (array) Capsule::table( 'tblorders' )->where( 'invoiceid', $invoiceid )->get( ['id'] );
    } catch ( Exception $e ) {
      return;
    }
    return $orders;
  }

  /**
   * { function_description }
   *
   * @param      array  $output  The output
   */
  private function output( $output = [] ) {
    $josn = json_encode( $output );
    header("Content-Type: application/json; charset=utf8");
    exit($josn);
  }

  /**
   * Gets the pr.
   *
   * @return     <type>  The pr.
   */
  private function get_pr() {
    return file_exists( ROOTDIR . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'addons' . DIRECTORY_SEPARATOR . 'encryptcoin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'class-transactions.php' );
  }
}
