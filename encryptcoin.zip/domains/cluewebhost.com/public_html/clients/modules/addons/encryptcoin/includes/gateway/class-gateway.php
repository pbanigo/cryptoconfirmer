<?php

namespace EncryptCoin;

! defined( 'WHMCS' ) && die( 'This file cannot be accessed directly' );

use \WHMCS\Database\Capsule;

/**
 *
 */
class BitcoinGateway extends EncryptCoin
{

  /**
   * [__construct description]
   *
   * @method __construct
   */
  function __construct() {
    return;
  }

  /**
   * [get description]
   *
   * @method get
   * @return [type] [description]
   */
  public function get_gateway( $invoiceid ) {
    $transaction = Capsule::table( 'encryptcoin_transactions' )->where( 'invoiceid', '=', $invoiceid )->where( 'confirmed', '=', '0' )->value( 'currency' );
    return $transaction ? [ $transaction ] : $this->check_addrsess();
  }

  /**
   * [check_addrsess description]
   *
   * @method check_addrsess
   * @param  [type]         $coins [description]
   * @return [type]                [description]
   */
  private function check_addrsess() {
    
    $has_table = Capsule::schema()->hasTable('encryptcoin_addresses');
    if ( ! $has_table ) {
      return false;
    }

    $addresses = [];

    try {
      $groups = Capsule::table('encryptcoin_addresses')->where( 'testnet', '=', parent::$testnet )->groupBy('code')->get( ['code'] );
      foreach ( $groups as $key => $value) {
        $addresses[] = $value->code;
      }
    } catch ( Exception $e ) {
      echo $e->getMessage();
    }

    return $addresses;
  }
}
