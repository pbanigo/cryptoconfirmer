<?php

namespace EncryptCoin;

! defined( 'WHMCS' ) && die( 'This file cannot be accessed directly' );

use WHMCS\Database\Capsule as Capsule;

/**
 *
 */
class EncryptCoinAddresses extends EncryptCoin
{

  /**
   * [private description]
   *
   * @var [type]
   */
  protected $info = [];

  /**
   * { var_description }
   *
   * @var        string
   */
  private $currency = '';

  /**
   * { var_description }
   *
   * @var        string
   */
  private $margin = 1.0;

  /**
   * { var_description }
   *
   * @var        string
   */
  private $invoiceid = '';

  /**
   * { var_description }
   *
   * @var        string
   */
  private $amount = '';

  /**
   * [__construct description]
   *
   * @method __construct
   * @param  [type]      $params [description]
   */
  function __construct( $params = [] ) {
    $info                     = [];
    $margin                   = (float) abs($params['ExchangeRateMargin']);
    $this->margin             = $margin <= 5 ? $margin: 1;
    $this->price              = $params['amount'];
    $this->original_currency  = $params['currency'];
    $this->currency           = parent::post_attr('encryptcoin');
    $this->invoiceid          = $params['invoiceid'];
    $this->date               = ( new \DateTime( "-30 minutes" ) )->format('Y-m-d H:i:s');
    $this->now                = ( new \DateTime() )->format('Y-m-d H:i:s');
    $tx                       = '1' === parent::post_attr( 'tx' );

    try {
      $transaction = ( array ) Capsule::table( 'encryptcoin_transactions' )->where( 'invoiceid', '=', $this->invoiceid )->where( 'confirmed', '=', '0' )->first();

      if ( is_array($transaction) && ! empty($transaction) ) {
        $transaction['sent'] = true;
      }

      $activitylog = Capsule::table( 'encryptcoin_activitylog' )
        ->where( 'invoiceid', '=', $this->invoiceid )
        ->where( 'currency', '=', $this->currency )
        ->where( 'price', '=', $this->price );

      if ( empty($transaction) ) {
        $activitylog = $activitylog->where( 'date', '>', $this->date );
      }

      $activity = ( array ) $activitylog->first();

      $info = is_array($transaction) && ! empty($transaction) ? $transaction : $activity;

    } catch ( Exception $e ) {
      echo $e->getMessage();
    }

    if ( ! $tx && ( empty( $info ) || $info['amount'] < 0.0000000001 ) ) {
      $info = $this->get_info();
    }

    if ( $tx && ! isset( $info['sent'] ) && $info['date'] < $this->date ) {
      exit( json_encode([
        'close' => true
      ]) );
    }

    if ( is_array($info) && !empty($info) && !isset($info['error']) ) {
      $info['margin'] = $this->get_margin($info['amount']);
    }

    if ( isset($info['id']) && ! isset($info['sent']) && $this->check_reserved($info) ) {
      $info = [
        'error' => 'addresses_are_reserved'
      ];
    }

    return $this->info = $info;
  }

  /**
   * Gets the margin.
   *
   * @param      integer  $amount  The amount
   *
   * @return     <type>   The margin.
   */
  private function get_margin( $amount ) {
    return $this->margin > 0 ? number_format( ((float) $amount * (float) $this->margin / 100), 10 ) : 0.0000000001;
  }

  /**
   * { function_description }
   *
   * @param      <type>   $info   The information
   *
   * @return     boolean  ( description_of_the_return_value )
   */
  private function check_reserved( $info ) {
    $activitylog = [];
    try {
      $activitylog = ( array ) Capsule::table( 'encryptcoin_activitylog' )->where( 'id', '!=', $info['id'] )->where( 'address', '=', $info['address'] )->where( 'currency', '=', $this->currency )->where( 'date', '>', $this->date )->first();
      if ( ! empty( $activitylog ) ) {
        $priority = ( array ) Capsule::table( 'encryptcoin_activitylog' )->where( 'address', '=', $info['address'] )->where( 'currency', '=', $this->currency )->where( 'date', '>', $this->date )->orderBy('date', 'asc')->first();
      }
    } catch ( Exception $e ) {
      echo $e->getMessage();
    }
    return ! empty( $activitylog ) && $priority['id'] === $info['id'];
  }

  /**
   * [get_info description]
   *
   * @method get_info
   * @return [type]                [description]
   */
  private function get_info( $ignor = '' ) {
    $address = $this->get_address( $ignor );

    if ( isset($address['error']) ) {
      return $address;
    }

    $amount = $this->get_amount();

    if ( ! $amount ) {
      return [
        'error' => 'amount'
      ];
    } elseif ( $amount <= 0.0000000001 ) {
      return [
        'error' => 'amount_is_zero'
      ];
    }

    $info = [
      'invoiceid' => $this->invoiceid,
      'address' => $address['address'],
      'currency' => $this->currency,
      'amount' => (string) number_format( $amount, 8),
      'price' => $this->price,
      'original_currency' => $this->original_currency,
      'date' => $this->now
    ];

    $this->update_addresses( $address['id'] ); // TODO: check if worked correctly

    try {
      $activitylog = ( array ) Capsule::table( 'encryptcoin_activitylog' )->where( 'invoiceid', '=', $this->invoiceid )->where( 'currency', '=', $this->currency )->first();

      if ( $activitylog && is_array($activitylog) && $activitylog['id'] ) {
        Capsule::table( 'encryptcoin_activitylog' )->where( 'id', '=', $activitylog['id'] )->update( $info );
      } else {
        Capsule::table( 'encryptcoin_activitylog' )->insert( $info );
      }
    } catch ( Exception $e ) {
      echo $e->getMessage();
    }

    return $info;
  }

  /**
   * Gets the amount.
   *
   * @return     <type>  The amount.
   */
  private function get_amount() {
    return (string) number_format(
      (new EncryptCoinConverter(
        $this->price,
        $this->original_currency
      ))->amount
    , 8 );
  }

  /**
   * [get_address description]
   *
   * @method get_address
   * @return [type]                   [description]
   */
  private function get_address( $ignor ) {
    $date = ( new \DateTime( "-60 minutes" ) )->format('Y-m-d H:i:s');;

    try {
      $address = ( array ) Capsule::table('encryptcoin_addresses')->where( 'testnet', '=', parent::$testnet )->where( 'code', '=', $this->currency )->where( 'address', '!=', $ignor )->orderBy('last_seen', 'asc')->first();

      if ( is_array( $address ) && ! empty( $address ) && ! empty( $address['address'] ) ) {
        if ( $address['last_seen'] > $date ) {
          return [
            'error' => 'addresses_are_reserved'
          ];
        } else {
          return $address;
        }
      }

    } catch ( Exception $e ) {
      echo $e->getMessage();
    }

    return [
      'error' => 'addresses_are_empty'
    ];
  }

  /**
   * [update description]
   *
   * @method update
   * @param  [type] $address     [description]
   * @return [type]              [description]
   */
  private function update_addresses( $id ) {
    try {
      $views = Capsule::table('encryptcoin_addresses')->where( 'id', '=', $id )->value( 'views' );

      $update = Capsule::table( 'encryptcoin_addresses' )->where( 'id', $id )->update([
        'views' => ++$views,
        'last_seen' => $this->now
      ]);

    } catch ( Exception $e ) {
      echo $e->getMessage();
    }
  }
}
