<?php
/**
 * EncryptCoin is a real peer-to-peer payment gateway for WHMCS which allows you to accept cryptocurrency payments
 * without transaction fees, monthly fee or bank account
 *
 * @package EncryptCoin
 * @author ZintaThemes
 * @version 1.0
 * @link https://zintathemes.com
 *
 */

! defined ( "WHMCS" ) && die ( "This file cannot be accessed directly" );


/**
 * This class contanes helper functions.
 *
 * @access     public
 * @author     Zinta
 * @package   EncryptCoin
 * @version   1.0
 */
if ( ! class_exists ( encryptCoinHelper ) ) {

  class encryptCoinHelper extends EncryptCoin
  {

      // --- ASSOCIATIONS ---

    /**
     *
     * @var unknown
     */
    public static $message = NULL;

      // --- ATTRIBUTES ---

    /**
     *
     *
     * @access   public
     * @author   zinta
     * @return   mixed
     * @version 1.0.0
     */
    public function __construct() {}


    /**
     * POST
     *
     * @access     private
     * @author     Zinta
     * @return     mixed
     * @version   1.0.0
     */
    public function _post( $param = null ) {
      return $_POST[$param];
    }

    /**
     * GET
     *
     * @access     private
     * @author     Zinta
     * @return     mixed
     * @version   1.0.0
     */
    public function _get( $param = null ) {
      return $_GET[$param];
    }

    /**
     * [message description]
     *
     * @method message
     * @param  [type]  $m [description]
     * @return [type]     [description]
     */
    public static function message( $msg = null, $state = 'success' ) {
      if ( empty( $msg ) ) return '';
      echo <<<HTML
      <tr>
        <td class="fieldarea" colspan="10">
          <div class="panel panel-health-check panel-health-check-{$state}">
            <div class="panel-heading"><small>{$msg}</small></div>
          </div>
        </td>
      </tr>
HTML;
    }

    /**
     * display success massge when admin click save
     *
     * @access     private
     * @author     Zinta
     * @return     mixed
     * @version   1.0.0
     */
    public function _success( $message ) {
      $this->message = '<div class="content-tab green white-text z-depth-1"><i class="fa fa-check"></i> '.$message.'</div>';
    }

    /**
     * display any error when admin click save in admin page
     *
     * @access     private
     * @author     Zinta
     * @return     mixed
     * @version   1.0.0
     */
    public function _error( $message ) {
      $this->message = '<div class="content-tab red white-text z-depth-1"><i class="fa fa-close"></i> '.$message.'</div>';
    }

  } /* end of class encryptCoinHelper */
}
