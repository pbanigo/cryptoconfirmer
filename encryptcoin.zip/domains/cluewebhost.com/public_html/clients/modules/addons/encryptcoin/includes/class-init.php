<?php
/**
 * EncryptCoin is a real peer-to-peer payment gateway for WHMCS which allows you to accept cryptocurrency payments
 * without transaction fees, monthly fee or bank account
 *
 * @author     ZintaThemes
 * @package   EncryptCoin
 * @since     1.0
 * @version   1.0.1
 */

use WHMCS\Database\Capsule;

! defined ( "WHMCS" ) && die ( "This file cannot be accessed directly" );

/**
 * Main class of encryptCoinAdmin addon, this class will be call in admin page only
 *
 * @access     public
 * @author     Zinta
 * @since     1.0
 * @version   1.0
 */
if ( ! class_exists ( encryptCoinAdmin ) ) {

  class encryptCoinInit extends encryptCoin
  {

    /**
     * [private description]
     *
     * @var [type]
     */
    private static $vars = [];

    /**
     * Construct function
     *
     * @access     public
     * @author     zinta
     * @return     mixed
     * @since     1.0
     * @version   1.0.0
     */
    public function __construct() {
      $this->libs();
      return true;
    }

    private function libs() {
      $libs = [ 'activitylog', 'addresses', 'addresseslist', 'details', 'helper', 'transactions', 'view' ];
      $path = dirname( __FILE__ ) . DIRECTORY_SEPARATOR;

      foreach ( $libs as $lib ) {
        $f = $path . 'class-' . $lib . '.php';
        file_exists( $f ) && require_once( $f );
      }
      self::$helper = new encryptCoinHelper();
    }

    /**
     * activate function will be call when EncryptCoin addon is activate
     *
     * @access     public
     * @author     Zinta
     * @return     mixed
     * @since     1.0
     * @version   1.0.0
     */
    public function activate() {
      $addresses = Capsule::schema()->hasTable('encryptcoin_addresses');
      $transactions = Capsule::schema()->hasTable('encryptcoin_transactions');
      $activitylog = Capsule::schema()->hasTable('encryptcoin_activitylog');

      if ( ! $addresses ) {
        try {
          Capsule::schema()->create(
            'encryptcoin_addresses',
            function( $table ) {
              $table->increments( 'id' );
              $table->string('code');
              $table->string('address');
              $table->integer('views');
              $table->integer('transactions');
              $table->string('clients');
              $table->dateTime('added_date');
              $table->dateTime('last_usage');
              $table->dateTime('last_seen');
              $table->boolean('testnet');
            }
          );

        } catch (\Exception $e) {
            echo "ERROR01: {$e->getMessage()}";
        }
      }

      if ( ! $transactions ) {
        try {
          Capsule::schema()->create(
            'encryptcoin_transactions',
            function( $table ) {
              $table->increments( 'id' );
              $table->integer('invoiceid');
              $table->string('transid')->unique();
              $table->string('hash')->unique();
              $table->string('address');
              $table->string('amount');
              $table->string('received_amount');
              $table->string('price');
              $table->string('received_price');
              $table->string('currency');
              $table->string('original_currency');
              $table->integer('confirmations');
              $table->integer('confirmed');
              $table->dateTime('date');
            }
          );
        } catch (\Exception $e) {
          echo "ERROR02: {$e->getMessage()}";
        }
      }

      if ( ! $activitylog ) {
        try {
          Capsule::schema()->create(
            'encryptcoin_activitylog',
            function( $table ) {
              $table->increments( 'id' );
              $table->integer('invoiceid');
              $table->string('address');
              $table->string('currency');
              $table->string('amount');
              $table->string('original_currency');
              $table->string('price');
              $table->dateTime('date');
            }
          );
        } catch (\Exception $e) {
          echo "ERROR03: {$e->getMessage()}";
        }
      }
    }

    /**
     * Upgreade function
     *
     * @access     public
     * @author     Zinta
     * @return     mixed
     * @since     1.0
     * @version   1.0.0
     */
    public function upgrade( $vars = [] ) {

      $pdo = Capsule::connection()->getPdo();
      $pdo->beginTransaction();

      if ( version_compare( '3.1', $vars['version'] ) >= 0 ) {
        try {
          Capsule::schema()->table('encryptcoin_addresses', function ( $table ) {
            return $table->dropUnique(['address']);
          });
        } catch ( Exception $e ) {
          self::msg(
            'ERROR24: ' . $e->getMessage(),
            'danger'
          );
        }
      }

      if ( version_compare( '3.99', $vars['version'] ) >= 0 ) {
        try {
          $update = $pdo->prepare( 'ALTER TABLE `encryptcoin_activitylog` CHANGE `original_amount` `price` VARCHAR(255) NOT NULL;' )->execute() && $pdo->prepare( 'ALTER TABLE `encryptcoin_transactions` CHANGE `original_amount` `price` VARCHAR(255) NOT NULL;' )->execute() && $pdo->prepare( 'ALTER TABLE `encryptcoin_transactions` ADD `received_price` VARCHAR(255) NOT NULL AFTER `price`;' )->execute() && $pdo->prepare( 'ALTER TABLE `encryptcoin_transactions` ADD `received_amount` VARCHAR(255) NOT NULL AFTER `price`;' )->execute();
        } catch (\Exception $e) {
          self::msg(
            'ERROR13: ' . $e->getMessage(),
            'danger'
          );
        }
      }

      $pdo->commit();

      $update && self::msg(
        'Database Updated to 4.0...'
      );

    }

    /**
     * deactivate function will be call when EncryptCoin addon is deactivate
     *
     * @access     public
     * @author     Zinta
     * @return     mixed
     * @since     1.0
     * @version   1.0.0
     */
    public function deactivate() {
      return;
    }

    /**
     * admin output
     *
     * @access     public
     * @author     Zinta
     * @return     mixed
     * @since     1.0
     * @version   1.0.0
     */
    public function output() {
      $conf = $this->get_conf();

      self::$testnet = $conf['testNet'] === 'on';

      if ( self::$testnet ) {
        $_currencies = self::$_currencies;
        self::$_currencies = [
          'BTC' => $_currencies['BTC'],
          // 'BCH' => $_currencies['BCH'],
          // 'ETH' => $_currencies['ETH']
        ];
      }

      if ( encryptCoinHelper::_get( 'transaction' ) || encryptCoinHelper::_get( 'address' ) ) {
        $this->details();
      } else {
        $this->parse_content();
        $this->contents();
      }
    }

    /**
     * display admin content at the page of encryptcoin
     *
     * @access     private
     * @author     Zinta
     * @return     mixed
     * @since     1.0
     * @version   1.0.0
     */
    private function parse_content() {
      $action = self::$helper->_post('action');
      $list = self::$helper->_get('list');

      ! empty($list) && 'transactions' === $list && $this->transactions_list();
      ! empty($list) && 'activitylog' === $list && $this->activitylog_list();
      ! empty($list) && 'addresses' === $list && $this->addresses_list();
      ! empty($action) && 'save-list' === $action && $this->save_list();
    }

    /**
     * { function_description }
     */
    private function transactions_list() {
      $transactions = new encryptCoinTransactions();
      // $transactions->transactions();
    }

    /**
     * [addresses description]
     *
     * @method addresses
     * @param  [type]    $vars [description]
     * @return [type]          [description]
     */
    private function addresses_list() {
      new encryptCoinAddressesList();
    }

    /**
     * [addresses description]
     *
     * @method addresses
     * @param  [type]    $vars [description]
     * @return [type]          [description]
     */
    private function activitylog_list() {
      new encryptCoinActivitylog();
    }

    /**
     * display admin content at the page of encryptcoin
     *
     * @access     private
     * @return     mixed
     * @since     1.0
     * @version   1.0.0
     */
    private function contents() {
      new encryptCoinView();
    }

    /**
     * { function_description }
     *
     * @method details
     * @param  [type]    $vars [description]
     * @return [type]          [description]
     */
    private function details() {
      class_exists( 'encryptCoinDetails' ) && new encryptCoinDetails();
    }

    /**
     * Save list
     *
     * @method save_list
     * @param  [type]    $vars [description]
     * @return [type]          [description]
     */
    private function save_list() {
      $address  = self::$helper->_post('address');
      $code     = self::$helper->_post('code');
      $state    = self::$helper->_post('state');
      $message  = 'danger' === $state ? 'ERROR03: ' . self::$lang['invalidAddress']  : self::$lang['addressSuccessAdded'];

      $BTC_regex = $regex = '/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,39}$/';
      $BCH_regex = '/^((13)[a-km-zA-HJ-NP-Z1-9]{25,34})|^(bitcoincash:)?((q|p)[a-z0-9]{41})$/';
      $DASH_regex = '/^(X)[a-zA-Z0-9]{33}$/';
      $ETH_regex = '/^0x[a-fA-F0-9]{40}$/';
      $USDT_regex = '/^0x[a-fA-F0-9]{40}$/';
      # $LTC_regex = '/^(L|M|3)[a-km-zA-HJ-NP-Z1-9]{26,33}$/';
      $LTC_regex = '/^(ltc1|[L|M|3])[a-zA-HJ-NP-Z0-9]{26,40}$/';
      $XRP_regex = '/^([r][0-9a-zA-Z]{24,34}){1}(:)?([0-9]{9,})?$/';

      if ( true === self::$testnet ) {
        $BTC_regex = $regex = '/^(tb1|m|n)[a-zA-HJ-NP-Z0-9]{25,39}$/';
        // $BTC_regex = $regex = '/^(m|n)[a-zA-HJ-NP-Z0-9]{25,33}$/';
        $BCH_regex = '/^bchtest:(q|p)[a-z0-9]{41}$/';
        $DASH_regex = '/^(y)[a-zA-Z0-9]{33}$/';
      }

      if ( 'success' === $state ) {

        switch ( $code ) {
          case 'BCH':
            $regex = $BCH_regex;
            break;

          case 'ETH':
            $regex = $ETH_regex;
            break;

          case 'USDT':
            $regex = $USDT_regex;
            break;

          case 'DASH':
            $regex = $DASH_regex;
            break;

          case 'LTC':
            $regex = $LTC_regex;
            break;

          case 'XRP':
            $regex = $XRP_regex;
            break;

          default:
            $regex = $BTC_regex;
            break;
        }

        if ( preg_match( $regex, $address ) ) {
          try {
            $check = (array) Capsule::table('encryptcoin_addresses')->where( 'address', '=', $address )->where( 'code', '=', $code )->where( 'testnet', '=', self::$testnet )->first();
            if ( ! empty( $check ) && $address === $check['address'] ) {
              $state = 'danger';
              $message = 'ERROR05: ' . self::$lang['addressExist'];
            } else {

              try {
                $now = date('Y-m-d H:i:s');

                $data = [
                  'code' => $code,
                  'address' => trim($address),
                  'views' => '0',
                  'clients' => '',
                  'added_date' => $now,
                  'testnet' => self::$testnet
                ];
                if ( ! Capsule::table( 'encryptcoin_addresses' )->insert( $data ) ) {
                  $message = 'ERROR06: ' . self::$lang['cannotUpdateDatabase'];
                }
              } catch ( Exception $e) {
                $state = 'danger';
                $message = 'ERROR07: ' . $e->getMessage();
              }

            }
          } catch (Exception $e) {
            $state = 'danger';
            $message = 'ERROR08: ' . $e->getMessage();
          }
        } else {
          $state = 'danger';
          $message = 'ERROR09: ' . self::$lang['invalidAddress'];
        }
      }

      $message = "{$code} - <code>{$address}</code><br/><small>{$message}</small>";

      self::msg( $message, $state );
      exit();
    }

    /**
     * Alert Version functcion
     *
     * @method version_alert
     * @param  [type]    $vars [description]
     * @return [type]          [description]
     */
    protected static function version_alert() {
      if ( ! function_exists('curl_version') || ( isset($_COOKIE['encryptcoin_mesg_ver']) && $_COOKIE['encryptcoin_mesg_ver'] === '1' ) ) {
        return;
      }

      $setcookie = [
        'expires' => time() + 3600,
        'path' => '/',
        'secure' => false,
        'samesite' => false
      ];

      $p = class_exists( 'encryptCoinAddresses' ) ? '1' : '0';

      $ch = curl_init();
      curl_setopt_array( $ch, [
         CURLOPT_URL => 'https://zintathemes.com/api/?zintathemes=mesg&item=encryptcoin&version=' . parent::$version,
         CURLOPT_TIMEOUT => 10,
         CURLOPT_RETURNTRANSFER => true,
      ]);
      $response = json_decode( curl_exec($ch), true );
      $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      curl_close($ch);

      if ( 200 === $httpcode && is_array($response) && ! empty($response) && ! empty($response['message']) ) {
        setcookie(
          'encryptcoin_mesg_ver',
          '0',
          $setcookie['expires'],
          $setcookie['path'],
          '',
          $setcookie['secure']
        );
        return self::msg(
          sprintf(
            $response['message'],
            parent::$version
          ),
          isset($response['type']) ? $response['type'] : 'info'
        );
      }
      setcookie(
        'encryptcoin_mesg_ver',
        '1',
        $setcookie['expires'],
        $setcookie['path'],
        '',
        $setcookie['secure']
      );
    }

    /**
     * { function_description }
     *
     * @param      <type>  $state    The state
     * @param      <type>  $message  The message
     */
    private static function msg( $message = null, $state = 'check' ) {
      if ( ! $message ) echo '';
      $icon = 'danger' === $state ? 'times-circle' : 'check';
      echo <<<HTML
      <hr/>
      <div class="panel panel-health-check panel-health-check-{$state}">
        <div class="panel-body" style="padding-top: 10px;">
          <i class="fas fa-{$icon}"></i> {$message}
        </div>
      </div>
HTML;
    }

    /**
     * admin sidebar
     *
     * @access     public
     * @author     Zinta
     * @return     mixed
     * @since     1.0
     * @version   1.0.0
     */
    public function sidebar() {
      return $sidebar = '';
    }

    /**
     * Gets the variables.
     *
     * @return     array  The variables.
     */
    private function get_conf() {
      require_once ROOTDIR . '/includes/gatewayfunctions.php';
      if ( function_exists('getGatewayVariables') ) {
        $vars = getGatewayVariables('encryptcoin');
        return [
          'testNet' => $vars['testNet']
        ];
      }
    }

  } /* end of class encryptCoinAdmin */
}
