<?php
/**
 * EncryptCoin is a real peer-to-peer payment gateway for WHMCS which allows you to accept cryptocurrency payments
 * without transaction fees, monthly fee or bank account
 *
 * @package EncryptCoin
 * @author ZintaThemes
 * @version 4.1.3
 * @link https://zintathemes.com
 *
 */

! defined('WHMCS') && die('This file cannot be accessed directly');

/**
 * Define EncryptCoin constantes.
 */
! defined( "ENCRYPTCOIN_PATH" ) && define( 'ENCRYPTCOIN_PATH', dirname( __FILE__ ) . DIRECTORY_SEPARATOR );

class encryptCoin
{

  /**
  * [protected description]
  *
  * @var [type]
  */
  protected static $helper;

  /**
  * instance
  *
  * @var boolean
  */
  private static $_instance = false;

  /**
  * [protected description]
  *
  * @var [type]
  */
  protected static $testnet = false;

  /**
   * [protected description]
   *
   * @var [type]
   */
  public $init;

  /**
   * [protected description]
   *
   * @var [type]
   */
  protected static $name = 'EncryptCoin';

  /**
   * [protected description]
   *
   * @var [type]
   */
  protected static $description = 'Real peer-to-peer payment gateway for WHMCS which allows you to accept cryptocurrency payments without transactions fee, monthly fee or bank account.<br /> Find out more <a target="_blank" href="https://zintathemes.com/">ZintaThemes</a>';

  /**
   * [protected description]
   *
   * @var [type]
   */
  protected static $author = 'ZintaThemes';

  /**
   * [protected description]
   *
   * @var [type]
   */
  protected static $language = 'english';

  /**
   * [protected description]
   *
   * @var [type]
   */
  protected static $version = '4.1.3';

  /**
   * [protected description]
   *
   * @var [type]
   */
  protected static $lang = [];

  /**
   * currencies code
   *
   * @var        array
   */
  protected static $_currencies = [
    'BTC' => [
      'name' => 'Bitcoin',
      'slug' => 'bitcoin'
    ],
    'BCH' => [
      'name' => 'Bitcoin Cash',
      'slug' => 'bitcoincash'
    ],
    'ETH' => [
      'name' => 'Ethereum',
      'slug' => 'ethereum'
    ],
    'USDT' => [
      'name' => 'Tether',
      'slug' => 'tether',
    ],
    'LTC' => [
      'name' => 'Litecoin',
      'slug' => 'litecoin'
    ],
    'DASH' => [
      'name' => 'Dash',
      'slug' => 'dash'
    ],
    'XRP' => [
      'name' => 'XRP',
      'slug' => 'xrp'
    ],
  ];

  /**
   * start instanc
   *
   * @method __construct
   */
  function __construct( $vars = [] ) {
    require_once ENCRYPTCOIN_PATH . 'includes' . DIRECTORY_SEPARATOR . 'class-init.php';
    self::$lang = $vars['_lang'];
    $this->init = new encryptCoinInit();
  }

  /**
   * [vars description]
   *
   * @method vars
   * @param  [type] $vars [description]
   * @return [type]       [description]
   */
  public static function config() {
    return [
      'name' => self::$name,
      'description' => self::$description,
      'version' => self::$version,
      'author' => self::$author,
      'language' => self::$language
    ];
  }

  /**
   * { function_description }
   *
   * @return     <type>  ( description_of_the_return_value )
   */
  public function start( $vars = [] ) {
    if ( ! self::$_instance ) {
      self::$_instance = new self( $vars );
    }
    return self::$_instance;
  }
}

/**
 * Configa function, this will return addon gonfigration
 *
 * @author      zinta
 * @return      configarray
 * @since       1.0
 * @version     3.0.0
 */
function encryptcoin_config() {
  return encryptCoin::config();
}

/**
 * Activate function, this will be called at addon is activate
 *
 * @author         zinta
 * @return         encryptcoin_activate
 * @since         1.0
 * @version     3.0.0
 */
function encryptcoin_activate() {
  encryptCoin::start()->init->activate();
}

/**
 * Upgreade function
 *
 * @author         zinta
 * @return         encryptcoin_upgrade
 * @since         1.0
 * @version     3.0.0
 */
function encryptcoin_upgrade( $vars = [] ) {
  encryptCoin::start( $vars )->init->upgrade( $vars );
}

/**
 * Deactivate function, this will be called at addon is deactivate
 *
 * @author         zinta
 * @return         encryptcoin_deactivate
 * @since         1.0
 * @version     3.0.0
 */
function encryptcoin_deactivate() {
  encryptCoin::start()->init->deactivate();
}

/**
 * Output function, encryptcoin output for addon admin page
 *
 * @author         zinta
 * @return         encryptcoin_output
 * @since         1.0
 * @version     3.0.0
 */
function encryptcoin_output( $vars = [] ) {
  encryptCoin::start( $vars )->init->output();
}

/**
 * Admin page sidebar
 *
 * @author         zinta
 * @return         encryptcoin_sidebar
 * @since         1.0
 * @version     3.0.0
 */
function encryptcoin_sidebar( $vars = [] ) {
  return encryptCoin::start( $vars )->init->sidebar();
}
